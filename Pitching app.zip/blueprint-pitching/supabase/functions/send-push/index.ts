// Supabase Edge Function: send-push
// -----------------------------------------------------------------------------
// Triggered by a Database Webhook on INSERT into `messages` and
// `team_messages` (configured in the Supabase dashboard — see README "Push
// Notifications"). Looks up who should be notified, then sends a Web Push
// notification to every device they've enabled notifications on.
//
// Required secrets (set with `supabase secrets set`):
//   VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT (e.g. mailto:you@example.com)
// Auto-provided by Supabase at runtime:
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
// -----------------------------------------------------------------------------

import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const vapidPublicKey = Deno.env.get("VAPID_PUBLIC_KEY")!;
const vapidPrivateKey = Deno.env.get("VAPID_PRIVATE_KEY")!;
const vapidSubject = Deno.env.get("VAPID_SUBJECT") || "mailto:coach@example.com";

webpush.setVapidDetails(vapidSubject, vapidPublicKey, vapidPrivateKey);

const supabase = createClient(supabaseUrl, serviceRoleKey);

async function sendTo(ownerId: string, payload: Record<string, unknown>) {
  const { data: subs, error } = await supabase
    .from("push_subscriptions")
    .select("id, endpoint, subscription")
    .eq("owner_id", ownerId);

  if (error || !subs) return;

  await Promise.all(
    subs.map(async (row) => {
      try {
        await webpush.sendNotification(row.subscription, JSON.stringify(payload));
      } catch (err: any) {
        // 410/404 means the subscription is dead (uninstalled, expired) — clean it up
        if (err?.statusCode === 410 || err?.statusCode === 404) {
          await supabase.from("push_subscriptions").delete().eq("id", row.id);
        }
      }
    })
  );
}

Deno.serve(async (req) => {
  try {
    const { table, record } = await req.json();

    if (table === "messages") {
      // record: { client_id, sender, body }
      if (record.sender === "client") {
        await sendTo("coach", {
          title: `New message — ${record.client_id}`,
          body: record.body,
          url: `/?coach=1`,
        });
      } else {
        await sendTo(record.client_id, {
          title: "New message from your coach",
          body: record.body,
          url: `/?client=${record.client_id}`,
        });
      }
    }

    if (table === "team_messages") {
      // record: { sender_id, sender_name, body }
      const { data: allSubs } = await supabase
        .from("push_subscriptions")
        .select("owner_id")
        .neq("owner_id", record.sender_id);

      const recipients = [...new Set((allSubs || []).map((r) => r.owner_id))];
      await Promise.all(
        recipients.map((ownerId) =>
          sendTo(ownerId, {
            title: `Team update from ${record.sender_name}`,
            body: record.body,
            url: ownerId === "coach" ? "/?coach=1" : `/?client=${ownerId}`,
          })
        )
      );
    }

    return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
  } catch (err) {
    console.error("send-push error:", err);
    return new Response(JSON.stringify({ ok: false }), { status: 500, headers: { "Content-Type": "application/json" } });
  }
});
