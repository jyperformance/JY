-- Run this once in your Supabase project's SQL editor.
-- Replaces the old boolean-only "progress" table with a richer "logs" table
-- that stores a full dated entry (weight, video, which drill, which week)
-- per exercise instead of just true/false.

create table if not exists logs (
  id bigint generated always as identity primary key,
  client_id text not null,
  exercise_id text not null,
  data jsonb not null,        -- { date, weight, video, name, detail, domain, week }
  updated_at timestamptz not null default now(),
  unique (client_id, exercise_id)
);

create index if not exists logs_client_id_idx on logs (client_id);

-- Row Level Security: open read/write for now since clients aren't logging
-- in with individual accounts — access is gated by the client-side PIN
-- instead. Fine for a small number of trusted client links. Tighten this
-- later if you add real per-client authentication.
alter table logs enable row level security;

create policy "Allow all access to logs"
  on logs
  for all
  using (true)
  with check (true);

-- If you're migrating from the earlier schema, you can drop the old table:
-- drop table if exists progress;

-- ----------------------------------------------------------------------------
-- MESSAGES — in-app chat between coach and each client, so you don't need
-- to text from your personal number.
-- ----------------------------------------------------------------------------
create table if not exists messages (
  id bigint generated always as identity primary key,
  client_id text not null,
  sender text not null check (sender in ('coach', 'client')),
  body text not null default '',
  video_url text,                -- optional throwing clip, uploaded to the chat-videos bucket
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists messages_client_id_idx on messages (client_id);
create index if not exists messages_created_at_idx on messages (created_at);

alter table messages enable row level security;

create policy "Allow all access to messages"
  on messages
  for all
  using (true)
  with check (true);

-- ----------------------------------------------------------------------------
-- TEAM MESSAGES — one shared channel for the coach and every client, for
-- announcements and general news. Everyone can read and post.
-- ----------------------------------------------------------------------------
create table if not exists team_messages (
  id bigint generated always as identity primary key,
  sender_id text not null,       -- "coach" or a client key from clients.js
  sender_name text not null,     -- display name at time of posting
  body text not null default '',
  video_url text,                -- optional throwing clip, uploaded to the chat-videos bucket
  created_at timestamptz not null default now()
);

create index if not exists team_messages_created_at_idx on team_messages (created_at);

alter table team_messages enable row level security;

create policy "Allow all access to team_messages"
  on team_messages
  for all
  using (true)
  with check (true);

-- ----------------------------------------------------------------------------
-- PUSH SUBSCRIPTIONS — one row per device that's opted in to push
-- notifications, so a Supabase Edge Function can look up who to notify
-- when a new message comes in. See README "Push Notifications" section.
-- ----------------------------------------------------------------------------
create table if not exists push_subscriptions (
  id bigint generated always as identity primary key,
  owner_id text not null,        -- "coach" or a client key from clients.js
  endpoint text not null unique,
  subscription jsonb not null,   -- full PushSubscription object (endpoint + keys)
  created_at timestamptz not null default now()
);

create index if not exists push_subscriptions_owner_id_idx on push_subscriptions (owner_id);

alter table push_subscriptions enable row level security;

create policy "Allow all access to push_subscriptions"
  on push_subscriptions
  for all
  using (true)
  with check (true);

-- ----------------------------------------------------------------------------
-- DATABASE WEBHOOKS (set up in the Supabase dashboard, not SQL):
-- Database > Webhooks > Create a new hook
--   1. Table: messages        Events: Insert   ->  calls the send-push Edge Function
--   2. Table: team_messages   Events: Insert   ->  calls the send-push Edge Function
-- See README "Push Notifications" for the full walkthrough.
-- ----------------------------------------------------------------------------

-- ----------------------------------------------------------------------------
-- PROGRAM WEEKS — lets you edit a client's programming from inside the app
-- (coach dashboard → open client → Edit) instead of hand-editing
-- clients.js. A row here overrides (or adds to) the static week for that
-- client/domain/date; `deleted = true` is a tombstone that removes a
-- static week from clients.js without needing to touch that file.
-- Once Supabase is connected, this table is the real source of truth —
-- clients.js becomes seed/demo content. See README "Editing Programming".
-- ----------------------------------------------------------------------------
create table if not exists program_weeks (
  id bigint generated always as identity primary key,
  client_id text not null,
  domain text not null,          -- prep | throwing | lifting | conditioning | armcare
  week_start date not null,      -- Monday of the week, e.g. 2026-08-24
  focus text,
  blocks jsonb not null default '[]'::jsonb,
  deleted boolean not null default false,
  updated_at timestamptz not null default now(),
  unique (client_id, domain, week_start)
);

create index if not exists program_weeks_client_id_idx on program_weeks (client_id);

alter table program_weeks enable row level security;

create policy "Allow all access to program_weeks"
  on program_weeks
  for all
  using (true)
  with check (true);

-- ----------------------------------------------------------------------------
-- READINESS CHECK-INS — a quick daily sleep/soreness/energy self-report
-- from the client, shown once per day before their program. Lets you catch
-- a client breaking down before they say anything.
-- ----------------------------------------------------------------------------
create table if not exists readiness_checkins (
  id bigint generated always as identity primary key,
  client_id text not null,
  date date not null,            -- the calendar day this check-in is for
  sleep smallint not null check (sleep between 1 and 5),
  soreness smallint not null check (soreness between 1 and 5),
  energy smallint not null check (energy between 1 and 5),
  note text,
  created_at timestamptz not null default now(),
  unique (client_id, date)
);

create index if not exists readiness_checkins_client_id_idx on readiness_checkins (client_id);
create index if not exists readiness_checkins_date_idx on readiness_checkins (date);

alter table readiness_checkins enable row level security;

create policy "Allow all access to readiness_checkins"
  on readiness_checkins
  for all
  using (true)
  with check (true);

-- ----------------------------------------------------------------------------
-- CLIENTS — lets you add a new client from inside the app (coach dashboard
-- → + Add Client) instead of hand-editing clients.js and redeploying. A row
-- here is layered on top of the static roster in clients.js at runtime —
-- clients.js stays useful for your original/seed clients, this table is
-- where anyone added later lives. `key` matches the client's URL:
-- yoursite.com/?client={key}
-- ----------------------------------------------------------------------------
create table if not exists clients (
  key text primary key,
  name text not null,
  pin text not null,
  archived boolean not null default false,
  created_at timestamptz not null default now()
);

alter table clients enable row level security;

create policy "Allow all access to clients"
  on clients
  for all
  using (true)
  with check (true);

-- ----------------------------------------------------------------------------
-- CHAT VIDEOS — storage bucket for throwing clips athletes upload directly
-- in Messages or the Team channel. Buckets can't be created by plain SQL
-- reliably across all Supabase project versions, so create this one from
-- the dashboard instead:
--
--   1. Storage → Create a new bucket
--      Name: chat-videos
--      Public bucket: ON (so uploaded clips can be viewed via a plain URL
--        in a chat bubble without a separate auth step — same permissive
--        model as the rest of this app; anyone with a specific video's
--        link can view it, but the bucket isn't browsable/listable)
--   2. Then run the two policy statements below in the SQL editor so the
--      app (using the public anon key) is allowed to upload and read.
-- ----------------------------------------------------------------------------
create policy "Allow public read of chat videos"
  on storage.objects for select
  using (bucket_id = 'chat-videos');

create policy "Allow uploads to chat videos"
  on storage.objects for insert
  with check (bucket_id = 'chat-videos');
