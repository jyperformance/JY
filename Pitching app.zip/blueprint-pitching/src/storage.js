import { supabase } from "./supabaseClient";

/**
 * Load all logged entries for a client.
 * Returns { [exerciseId]: { date, weight, video, name, detail, domain, week } }
 */
export async function loadLogs(clientId) {
  if (supabase) {
    const { data, error } = await supabase.from("logs").select("exercise_id, data").eq("client_id", clientId);
    if (error) {
      console.error("Supabase load error:", error);
      return {};
    }
    const result = {};
    (data || []).forEach((row) => {
      result[row.exercise_id] = row.data;
    });
    return result;
  }

  try {
    const raw = localStorage.getItem(`bp-logs-${clientId}`);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    console.error("localStorage load error:", e);
    return {};
  }
}

/**
 * Save (or overwrite) a single exercise's log entry.
 */
export async function saveLog(clientId, exerciseId, entry) {
  if (supabase) {
    const { error } = await supabase
      .from("logs")
      .upsert(
        { client_id: clientId, exercise_id: exerciseId, data: entry, updated_at: new Date().toISOString() },
        { onConflict: "client_id,exercise_id" }
      );
    if (error) console.error("Supabase save error:", error);
    return;
  }

  try {
    const key = `bp-logs-${clientId}`;
    const raw = localStorage.getItem(key);
    const current = raw ? JSON.parse(raw) : {};
    current[exerciseId] = entry;
    localStorage.setItem(key, JSON.stringify(current));
  } catch (e) {
    console.error("localStorage save error:", e);
  }
}

/**
 * Remove a single exercise's log entry (unchecking it).
 */
export async function deleteLog(clientId, exerciseId) {
  if (supabase) {
    const { error } = await supabase.from("logs").delete().eq("client_id", clientId).eq("exercise_id", exerciseId);
    if (error) console.error("Supabase delete error:", error);
    return;
  }

  try {
    const key = `bp-logs-${clientId}`;
    const raw = localStorage.getItem(key);
    const current = raw ? JSON.parse(raw) : {};
    delete current[exerciseId];
    localStorage.setItem(key, JSON.stringify(current));
  } catch (e) {
    console.error("localStorage delete error:", e);
  }
}

/**
 * Load logs for every client in one shot, for the coach dashboard.
 * Returns { [clientId]: { [exerciseId]: entry } }
 */
export async function loadAllClientLogs(clientIds) {
  if (supabase) {
    const { data, error } = await supabase.from("logs").select("client_id, exercise_id, data").in("client_id", clientIds);
    if (error) {
      console.error("Supabase load error:", error);
      return {};
    }
    const result = {};
    clientIds.forEach((id) => (result[id] = {}));
    (data || []).forEach((row) => {
      if (!result[row.client_id]) result[row.client_id] = {};
      result[row.client_id][row.exercise_id] = row.data;
    });
    return result;
  }

  // localStorage fallback — only sees data logged on this same device/browser
  const result = {};
  clientIds.forEach((id) => {
    try {
      const raw = localStorage.getItem(`bp-logs-${id}`);
      result[id] = raw ? JSON.parse(raw) : {};
    } catch (e) {
      result[id] = {};
    }
  });
  return result;
}

export const isUsingSupabase = !!supabase;

/* ============================================================================
   CHAT VIDEO UPLOADS — lets a client upload a throwing clip straight into
   Messages or the Team channel. Requires Supabase Storage (a "chat-videos"
   bucket) — see README "Video uploads in chat" for the one-time setup.
============================================================================ */

/**
 * Uploads a video file to the `chat-videos` Supabase Storage bucket and
 * returns its public URL, or null if it fails (including when Supabase
 * isn't configured — there's no practical local-only fallback for large
 * binary files).
 */
export async function uploadChatVideo(file, ownerId) {
  if (!supabase) return null;
  const ext = (file.name.split(".").pop() || "mp4").toLowerCase();
  const path = `${ownerId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const { error } = await supabase.storage.from("chat-videos").upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    contentType: file.type || "video/mp4",
  });
  if (error) {
    console.error("Supabase video upload error:", error);
    return null;
  }
  const { data } = supabase.storage.from("chat-videos").getPublicUrl(path);
  return data?.publicUrl || null;
}

/* ============================================================================
   DYNAMIC CLIENTS — lets you add a client from inside the app instead of
   hand-editing clients.js. Layered on top of the static roster at runtime.
============================================================================ */

/**
 * Every non-archived client added via the in-app form, as { [key]: { name, pin } }.
 */
export async function loadDynamicClients() {
  if (supabase) {
    const { data, error } = await supabase.from("clients").select("key, name, pin").eq("archived", false);
    if (error) {
      console.error("Supabase load clients error:", error);
      return {};
    }
    const result = {};
    (data || []).forEach((row) => { result[row.key] = { name: row.name, pin: row.pin }; });
    return result;
  }

  try {
    const raw = localStorage.getItem("bp-dynamic-clients");
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    console.error("localStorage load clients error:", e);
    return {};
  }
}

export async function createClient(key, name, pin) {
  if (supabase) {
    const { error } = await supabase.from("clients").insert({ key, name, pin });
    if (error) console.error("Supabase create client error:", error);
    return !error;
  }

  try {
    const raw = localStorage.getItem("bp-dynamic-clients");
    const current = raw ? JSON.parse(raw) : {};
    current[key] = { name, pin };
    localStorage.setItem("bp-dynamic-clients", JSON.stringify(current));
    return true;
  } catch (e) {
    console.error("localStorage create client error:", e);
    return false;
  }
}

/* ============================================================================
   PROGRAM EDITOR — coach-editable overrides on top of clients.js. A week
   here (keyed by client/domain/date) overrides or adds to the static
   content; a `deleted` row is a tombstone that hides a static week.
============================================================================ */

/**
 * Load every override for a client, grouped by domain then week date:
 *   { [domain]: { [weekStart]: { focus, blocks } | null } }
 * A value of `null` means that week is deleted (tombstoned).
 */
export async function loadProgramOverrides(clientId) {
  if (supabase) {
    const { data, error } = await supabase
      .from("program_weeks")
      .select("domain, week_start, focus, blocks, deleted")
      .eq("client_id", clientId);
    if (error) {
      console.error("Supabase load program overrides error:", error);
      return {};
    }
    const result = {};
    (data || []).forEach((row) => {
      if (!result[row.domain]) result[row.domain] = {};
      result[row.domain][row.week_start] = row.deleted ? null : { focus: row.focus || undefined, blocks: row.blocks };
    });
    return result;
  }

  try {
    const raw = localStorage.getItem(`bp-program-${clientId}`);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    console.error("localStorage load program overrides error:", e);
    return {};
  }
}

/**
 * Create or update a week's content for a client/domain.
 * weekData: { focus?: string, blocks: [{ title, items: [{name, detail, cue, video}] }] }
 */
export async function saveProgramWeek(clientId, domain, weekStart, weekData) {
  if (supabase) {
    const { error } = await supabase.from("program_weeks").upsert(
      {
        client_id: clientId,
        domain,
        week_start: weekStart,
        focus: weekData.focus || null,
        blocks: weekData.blocks,
        deleted: false,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "client_id,domain,week_start" }
    );
    if (error) console.error("Supabase save program week error:", error);
    return !error;
  }

  try {
    const key = `bp-program-${clientId}`;
    const raw = localStorage.getItem(key);
    const current = raw ? JSON.parse(raw) : {};
    if (!current[domain]) current[domain] = {};
    current[domain][weekStart] = weekData;
    localStorage.setItem(key, JSON.stringify(current));
    return true;
  } catch (e) {
    console.error("localStorage save program week error:", e);
    return false;
  }
}

/**
 * Tombstone a week so it no longer shows, even if clients.js still has a
 * static entry at that date.
 */
export async function deleteProgramWeek(clientId, domain, weekStart) {
  if (supabase) {
    const { error } = await supabase.from("program_weeks").upsert(
      { client_id: clientId, domain, week_start: weekStart, deleted: true, blocks: [], updated_at: new Date().toISOString() },
      { onConflict: "client_id,domain,week_start" }
    );
    return !error;
  }

  try {
    const key = `bp-program-${clientId}`;
    const raw = localStorage.getItem(key);
    const current = raw ? JSON.parse(raw) : {};
    if (!current[domain]) current[domain] = {};
    current[domain][weekStart] = null;
    localStorage.setItem(key, JSON.stringify(current));
    return true;
  } catch (e) {
    console.error("localStorage delete program week error:", e);
    return false;
  }
}

/* ============================================================================
   READINESS CHECK-INS — quick daily sleep/soreness/energy self-report.
============================================================================ */

/**
 * The client's check-in for a specific date, or null if they haven't done
 * one yet.
 */
export async function loadCheckin(clientId, date) {
  if (supabase) {
    const { data, error } = await supabase
      .from("readiness_checkins")
      .select("sleep, soreness, energy, note, date")
      .eq("client_id", clientId)
      .eq("date", date)
      .maybeSingle();
    if (error) {
      console.error("Supabase load checkin error:", error);
      return null;
    }
    return data || null;
  }

  try {
    const raw = localStorage.getItem(`bp-checkins-${clientId}`);
    const all = raw ? JSON.parse(raw) : {};
    return all[date] || null;
  } catch (e) {
    return null;
  }
}

export async function saveCheckin(clientId, date, { sleep, soreness, energy, note = "" }) {
  if (supabase) {
    const { error } = await supabase
      .from("readiness_checkins")
      .upsert({ client_id: clientId, date, sleep, soreness, energy, note: note || null }, { onConflict: "client_id,date" });
    if (error) console.error("Supabase save checkin error:", error);
    return !error;
  }

  try {
    const key = `bp-checkins-${clientId}`;
    const raw = localStorage.getItem(key);
    const all = raw ? JSON.parse(raw) : {};
    all[date] = { sleep, soreness, energy, note, date };
    localStorage.setItem(key, JSON.stringify(all));
    return true;
  } catch (e) {
    console.error("localStorage save checkin error:", e);
    return false;
  }
}

/**
 * For the coach dashboard: today's check-in (if any) per client, in one
 * shot.
 */
export async function loadTodayCheckinSummaries(clientIds, date) {
  if (supabase) {
    const { data, error } = await supabase
      .from("readiness_checkins")
      .select("client_id, sleep, soreness, energy, note")
      .in("client_id", clientIds)
      .eq("date", date);
    if (error) {
      console.error("Supabase load checkin summaries error:", error);
      return {};
    }
    const result = {};
    (data || []).forEach((row) => { result[row.client_id] = row; });
    return result;
  }

  const result = {};
  clientIds.forEach((id) => {
    try {
      const raw = localStorage.getItem(`bp-checkins-${id}`);
      const all = raw ? JSON.parse(raw) : {};
      if (all[date]) result[id] = all[date];
    } catch (e) {
      // skip
    }
  });
  return result;
}

/* ============================================================================
   TEAM CHANNEL — one shared thread everyone (coach + every client) can read
   and post in, for announcements and general news.
============================================================================ */

/**
 * Load the full team channel thread, oldest first.
 */
export async function loadTeamMessages() {
  if (supabase) {
    const { data, error } = await supabase
      .from("team_messages")
      .select("id, sender_id, sender_name, body, video_url, created_at")
      .order("created_at", { ascending: true });
    if (error) {
      console.error("Supabase load team messages error:", error);
      return [];
    }
    return data || [];
  }

  try {
    const raw = localStorage.getItem("bp-team-messages");
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error("localStorage load team messages error:", e);
    return [];
  }
}

/**
 * Post to the team channel. senderId is "coach" or a client key; senderName
 * is the display name to show (captured at post time). videoUrl is
 * optional — a public URL from uploadChatVideo().
 */
export async function sendTeamMessage(senderId, senderName, body, videoUrl = null) {
  const trimmed = body.trim();
  if (!trimmed && !videoUrl) return null;

  if (supabase) {
    const { data, error } = await supabase
      .from("team_messages")
      .insert({ sender_id: senderId, sender_name: senderName, body: trimmed, video_url: videoUrl })
      .select("id, sender_id, sender_name, body, video_url, created_at")
      .single();
    if (error) {
      console.error("Supabase send team message error:", error);
      return null;
    }
    return data;
  }

  try {
    const raw = localStorage.getItem("bp-team-messages");
    const current = raw ? JSON.parse(raw) : [];
    const entry = { id: `local-${Date.now()}-${Math.random().toString(36).slice(2)}`, sender_id: senderId, sender_name: senderName, body: trimmed, video_url: videoUrl, created_at: new Date().toISOString() };
    current.push(entry);
    localStorage.setItem("bp-team-messages", JSON.stringify(current));
    return entry;
  } catch (e) {
    console.error("localStorage send team message error:", e);
    return null;
  }
}

/* ============================================================================
   MESSAGES — in-app chat between coach and client, per client thread.
============================================================================ */

/**
 * Load a client's full message thread, oldest first.
 */
export async function loadMessages(clientId) {
  if (supabase) {
    const { data, error } = await supabase
      .from("messages")
      .select("id, sender, body, video_url, read, created_at")
      .eq("client_id", clientId)
      .order("created_at", { ascending: true });
    if (error) {
      console.error("Supabase load messages error:", error);
      return [];
    }
    return data || [];
  }

  try {
    const raw = localStorage.getItem(`bp-messages-${clientId}`);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error("localStorage load messages error:", e);
    return [];
  }
}

/**
 * Send a message in a client's thread. sender is "coach" or "client".
 * videoUrl is optional — a public URL from uploadChatVideo().
 */
export async function sendMessage(clientId, sender, body, videoUrl = null) {
  const trimmed = body.trim();
  if (!trimmed && !videoUrl) return null;

  if (supabase) {
    const { data, error } = await supabase
      .from("messages")
      .insert({ client_id: clientId, sender, body: trimmed, video_url: videoUrl, read: false })
      .select("id, sender, body, video_url, read, created_at")
      .single();
    if (error) {
      console.error("Supabase send message error:", error);
      return null;
    }
    return data;
  }

  try {
    const key = `bp-messages-${clientId}`;
    const raw = localStorage.getItem(key);
    const current = raw ? JSON.parse(raw) : [];
    const entry = { id: `local-${Date.now()}-${Math.random().toString(36).slice(2)}`, sender, body: trimmed, video_url: videoUrl, read: false, created_at: new Date().toISOString() };
    current.push(entry);
    localStorage.setItem(key, JSON.stringify(current));
    return entry;
  } catch (e) {
    console.error("localStorage send message error:", e);
    return null;
  }
}

/**
 * Mark all messages NOT sent by `readerRole` as read, for one client thread.
 * Call this when the coach opens a client's thread, or when the client
 * opens their Messages tab.
 */
export async function markMessagesRead(clientId, readerRole) {
  const otherSender = readerRole === "coach" ? "client" : "coach";

  if (supabase) {
    const { error } = await supabase
      .from("messages")
      .update({ read: true })
      .eq("client_id", clientId)
      .eq("sender", otherSender)
      .eq("read", false);
    if (error) console.error("Supabase mark read error:", error);
    return;
  }

  try {
    const key = `bp-messages-${clientId}`;
    const raw = localStorage.getItem(key);
    const current = raw ? JSON.parse(raw) : [];
    const next = current.map((m) => (m.sender === otherSender ? { ...m, read: true } : m));
    localStorage.setItem(key, JSON.stringify(next));
  } catch (e) {
    console.error("localStorage mark read error:", e);
  }
}

/**
 * For the coach dashboard: unread-from-client count + last message per
 * client, in one shot.
 */
export async function loadMessageSummaries(clientIds) {
  if (supabase) {
    const { data, error } = await supabase
      .from("messages")
      .select("client_id, sender, body, read, created_at")
      .in("client_id", clientIds)
      .order("created_at", { ascending: true });
    if (error) {
      console.error("Supabase load message summaries error:", error);
      return {};
    }
    const result = {};
    clientIds.forEach((id) => (result[id] = { unread: 0, lastMessage: null }));
    (data || []).forEach((m) => {
      if (!result[m.client_id]) result[m.client_id] = { unread: 0, lastMessage: null };
      result[m.client_id].lastMessage = m;
      if (m.sender === "client" && !m.read) result[m.client_id].unread += 1;
    });
    return result;
  }

  const result = {};
  clientIds.forEach((id) => {
    try {
      const raw = localStorage.getItem(`bp-messages-${id}`);
      const msgs = raw ? JSON.parse(raw) : [];
      const unread = msgs.filter((m) => m.sender === "client" && !m.read).length;
      const lastMessage = msgs.length ? msgs[msgs.length - 1] : null;
      result[id] = { unread, lastMessage };
    } catch (e) {
      result[id] = { unread: 0, lastMessage: null };
    }
  });
  return result;
}
