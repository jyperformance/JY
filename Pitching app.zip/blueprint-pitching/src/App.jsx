import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { Wind, Zap, Dumbbell, Timer, ShieldPlus, Check, ChevronDown, History as HistoryIcon, Video, Paperclip, X, Lock, Users, ArrowLeft, Smartphone, Share, MessageCircle, Send, Bell, BellOff, Megaphone, Pencil, Plus, Trash2, Moon, Battery, AlertTriangle, Search, UserPlus } from "lucide-react";
import { CLIENTS } from "./clients";
import {
  loadLogs, saveLog, deleteLog, loadAllClientLogs, isUsingSupabase,
  loadMessages, sendMessage, markMessagesRead, loadMessageSummaries,
  loadTeamMessages, sendTeamMessage, uploadChatVideo,
  loadProgramOverrides, saveProgramWeek, deleteProgramWeek,
  loadCheckin, saveCheckin, loadTodayCheckinSummaries,
  loadDynamicClients, createClient,
} from "./storage";
import { pushConfigured, getNotificationPermission, enablePushNotifications, isPushEnabled } from "./push";

const COACH_PIN = import.meta.env.VITE_COACH_PIN || "0000";

// Shared branding across every client — only training content + PIN differ per client (see clients.js)
const DOMAIN_META = {
  prep: { label: "Prep Work", tabLabel: "Prep", icon: Wind, accent: "#5FB8A6" },
  throwing: { label: "Throwing", tabLabel: "Throwing", icon: Zap, accent: "#E0A63B" },
  lifting: { label: "Lifting", tabLabel: "Lifting", icon: Dumbbell, accent: "#D9603B" },
  conditioning: { label: "Sprints & Conditioning", tabLabel: "Sprints", icon: Timer, accent: "#4C93D0" },
  armcare: { label: "Arm Care", tabLabel: "Arm Care", icon: ShieldPlus, accent: "#6FB35C" },
};
const DOMAIN_KEYS = Object.keys(DOMAIN_META);

// Default blurb for a domain a brand-new (in-app-added) client hasn't had
// customized yet. The coach can still write custom per-client blurbs by
// hand-editing clients.js if they want — this is just a sane starting point.
const DEFAULT_BLURBS = {
  prep: "Restore position before you ask for output.",
  throwing: "Volume and intent are managed on purpose, not by feel.",
  lifting: "Force production off the back leg and rotational power through the trunk.",
  conditioning: "Pitching is a repeated-sprint event, not an endurance event.",
  armcare: "This section never tapers.",
};
function buildEmptyPrograms() {
  const programs = {};
  DOMAIN_KEYS.forEach((dk) => { programs[dk] = { blurb: DEFAULT_BLURBS[dk], weeks: {} }; });
  return programs;
}
function slugifyName(name) {
  return name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-+|-+$)/g, "");
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}
function addDays(iso, n) {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}
function formatDate(iso) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}
// Short label for a week chip, e.g. "Aug 17"
function formatWeekChip(iso) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
// Full range for a week header, e.g. "Aug 17 – 23"
function formatWeekRange(iso) {
  const start = new Date(iso + "T00:00:00");
  const end = new Date(addDays(iso, 6) + "T00:00:00");
  const startLabel = start.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  const endLabel = start.getMonth() === end.getMonth()
    ? end.toLocaleDateString(undefined, { day: "numeric" })
    : end.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  return `${startLabel} – ${endLabel}`;
}
// Does `today` fall within the 7-day week starting at `weekStart`?
function isCurrentWeek(weekStart, today) {
  return weekStart <= today && addDays(weekStart, 6) >= today;
}
// Given the dated weeks that exist for a domain, pick which one to show by
// default: the week containing today, else the nearest upcoming week, else
// the most recent past week (program hasn't been extended yet).
function pickDefaultWeek(weekKeys, today) {
  if (weekKeys.length === 0) return null;
  const sorted = [...weekKeys].sort();
  const current = sorted.find((k) => isCurrentWeek(k, today));
  if (current) return current;
  const future = sorted.find((k) => k > today);
  if (future) return future;
  return sorted[sorted.length - 1];
}
// Monday of the week containing `iso` (or `iso` itself if it already is one)
function mondayOf(iso) {
  const d = new Date(iso + "T00:00:00");
  const day = d.getDay(); // 0 = Sun ... 6 = Sat
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  return d.toISOString().slice(0, 10);
}
function daysSince(iso, today) {
  return Math.round((new Date(today + "T00:00:00") - new Date(iso + "T00:00:00")) / 86400000);
}
// Short label for a single day chip, e.g. "Mon 10"
function formatDayChip(iso) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, { weekday: "short", day: "numeric" });
}
// Full label for a day header, e.g. "Monday, Aug 10"
function formatDayLabel(iso) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });
}
// The 7 calendar dates (Mon..Sun) for the week starting at `weekStart`
function daysOfWeek(weekStart) {
  return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
}
let uid = 0;
function nextUid() {
  uid += 1;
  return `u${uid}-${Date.now()}`;
}
function formatMsgTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}
function getUrlParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}
function setUrlParam(name, value) {
  const url = new URL(window.location);
  if (value) url.searchParams.set(name, value);
  else url.searchParams.delete(name);
  window.history.replaceState({}, "", url);
}
function isAuthed(clientId) {
  return sessionStorage.getItem(`bp-authed-${clientId}`) === "1";
}
function setAuthed(clientId) {
  sessionStorage.setItem(`bp-authed-${clientId}`, "1");
}

/* ============================================================================
   VIDEO MODAL — plays a self-hosted demo clip inline, on-site. No new tab,
   no third-party embed. Works with any direct video file URL (mp4, mov,
   webm, or a Supabase storage public URL).
============================================================================ */
function VideoModal({ url, title, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center px-4"
      style={{ backgroundColor: "#0A0E12dd" }}
      onClick={onClose}
    >
      <div className="w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-2 px-1">
          <span className="text-[15px] font-medium truncate pr-3" style={{ color: "#EDF1F4" }}>{title}</span>
          <button onClick={onClose} aria-label="Close video" className="flex-shrink-0 p-1 rounded-lg" style={{ color: "#8FA0AC" }}>
            <X size={18} />
          </button>
        </div>
        <div className="rounded-lg overflow-hidden" style={{ backgroundColor: "#000", border: "1px solid #263139" }}>
          <video src={url} controls autoPlay playsInline className="w-full h-auto max-h-[75vh]" />
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   MESSAGE THREAD — reusable chat UI. Used both in the client's Messages tab
   (role="client") and from the coach dashboard when replying to a client
   (role="coach"). Polls every few seconds when Supabase is connected so
   both sides see new messages without a manual refresh.
============================================================================ */
function MessageThread({ clientId, role, accent = "#C9A15F" }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [pendingVideo, setPendingVideo] = useState(null); // { url, name } | null
  const [uploading, setUploading] = useState(false);
  const [playingVideo, setPlayingVideo] = useState(null); // { url, title } | null
  const bottomRef = useRef(null);
  const fileInputRef = useRef(null);

  const refresh = useCallback(async () => {
    const data = await loadMessages(clientId);
    setMessages(data);
  }, [clientId]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      await refresh();
      await markMessagesRead(clientId, role);
      if (!cancelled) setLoading(false);
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clientId, role]);

  useEffect(() => {
    if (!isUsingSupabase) return undefined;
    const interval = setInterval(async () => {
      await refresh();
      await markMessagesRead(clientId, role);
    }, 4000);
    return () => clearInterval(interval);
  }, [clientId, role, refresh]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length]);

  const pickVideo = () => fileInputRef.current?.click();

  const handleVideoSelected = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setUploading(true);
    const url = await uploadChatVideo(file, clientId);
    setUploading(false);
    if (url) setPendingVideo({ url, name: file.name });
  };

  const submit = async () => {
    const text = draft.trim();
    if ((!text && !pendingVideo) || sending) return;
    setSending(true);
    const videoUrl = pendingVideo?.url || null;
    setDraft("");
    setPendingVideo(null);
    const optimistic = { id: `pending-${Date.now()}`, sender: role, body: text, video_url: videoUrl, read: false, created_at: new Date().toISOString() };
    setMessages((prev) => [...prev, optimistic]);
    await sendMessage(clientId, role, text, videoUrl);
    await refresh();
    setSending(false);
  };

  return (
    <div className="flex flex-col" style={{ minHeight: "50vh" }}>
      {!isUsingSupabase && (
        <div className="mb-3 rounded-lg px-3 py-2 text-[13.5px]" style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#8FA0AC" }}>
          No Supabase connection — messages only stay on this device for now, and video uploads are unavailable until Supabase Storage is connected. See README.
        </div>
      )}

      <div className="flex-1 space-y-2.5 mb-3">
        {loading && <div className="text-center py-8 bp-mono text-xs" style={{ color: "#5C6D78" }}>Loading…</div>}

        {!loading && messages.length === 0 && (
          <div className="rounded-lg p-6 text-center" style={{ border: "1px solid #263139" }}>
            <p className="bp-mono text-xs uppercase tracking-widest mb-1" style={{ color: "#5C6D78" }}>No Messages Yet</p>
            <p className="text-sm" style={{ color: "#8FA0AC" }}>
              {role === "coach" ? "Send the first message below." : "Your coach hasn't messaged yet — you can send one below."}
            </p>
          </div>
        )}

        {!loading && messages.map((m) => {
          const mine = m.sender === role;
          return (
            <div key={m.id} className="flex" style={{ justifyContent: mine ? "flex-end" : "flex-start" }}>
              <div className="max-w-[78%] rounded-lg px-3 py-2" style={{ backgroundColor: mine ? accent : "#1B252D", border: mine ? "none" : "1px solid #263139" }}>
                {m.video_url && (
                  <button
                    onClick={() => setPlayingVideo({ url: m.video_url, title: mine ? "Your video" : "Video" })}
                    className="relative flex items-center justify-center rounded-lg mb-1.5 overflow-hidden"
                    style={{ width: 180, height: 100, backgroundColor: "#000" }}
                  >
                    <video src={m.video_url} className="w-full h-full object-cover" muted />
                    <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: "#00000055" }}>
                      <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ backgroundColor: "#EDF1F4dd" }}>
                        <Video size={16} color="#12191F" />
                      </div>
                    </div>
                  </button>
                )}
                {m.body && <div className="text-[15px] leading-snug whitespace-pre-wrap" style={{ color: mine ? "#12191F" : "#EDF1F4" }}>{m.body}</div>}
                <div className="bp-mono text-[11px] mt-1" style={{ color: mine ? "#12191F99" : "#5C6D78" }}>{formatMsgTime(m.created_at)}</div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {pendingVideo && (
        <div className="flex items-center gap-2 mb-2 px-3 py-2 rounded-lg" style={{ backgroundColor: "#1B252D", border: `1px solid ${accent}55` }}>
          <Video size={14} style={{ color: accent }} />
          <span className="flex-1 text-[13px] truncate" style={{ color: "#AEBEC8" }}>{pendingVideo.name}</span>
          <button onClick={() => setPendingVideo(null)} aria-label="Remove attached video" style={{ color: "#8FA0AC" }}>
            <X size={14} />
          </button>
        </div>
      )}

      <div className="sticky bottom-0 flex items-end gap-2 pt-2" style={{ backgroundColor: "#12191F" }}>
        <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={handleVideoSelected} />
        <button
          onClick={pickVideo}
          disabled={uploading || !isUsingSupabase}
          aria-label="Attach a throwing video"
          className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ border: "1px solid #263139", color: isUsingSupabase ? "#8FA0AC" : "#3A4750" }}
          title={isUsingSupabase ? "Attach a video" : "Connect Supabase to enable video uploads"}
        >
          {uploading ? <span className="bp-mono text-[9px]">…</span> : <Paperclip size={16} />}
        </button>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
          }}
          placeholder={role === "coach" ? "Message this client…" : "Message your coach…"}
          rows={1}
          className="flex-1 text-[15px] rounded-lg px-3 py-2.5 resize-none"
          style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#EDF1F4", maxHeight: 100 }}
        />
        <button
          onClick={submit}
          disabled={(!draft.trim() && !pendingVideo) || sending}
          aria-label="Send message"
          className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: draft.trim() || pendingVideo ? accent : "#263139", color: draft.trim() || pendingVideo ? "#12191F" : "#5C6D78" }}
        >
          <Send size={16} />
        </button>
      </div>

      {playingVideo && <VideoModal url={playingVideo.url} title={playingVideo.title} onClose={() => setPlayingVideo(null)} />}
    </div>
  );
}

/* ============================================================================
   TEAM CHANNEL — one shared thread for the coach and every client. Anyone
   can post; everyone sees everyone's name (unlike the 1:1 MessageThread,
   where only two parties exist so bubbles just need "mine vs. theirs").
============================================================================ */
function TeamChannel({ selfId, selfName, readOnly = false, accent = "#C9A15F" }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [pendingVideo, setPendingVideo] = useState(null); // { url, name } | null
  const [uploading, setUploading] = useState(false);
  const [playingVideo, setPlayingVideo] = useState(null); // { url, title } | null
  const bottomRef = useRef(null);
  const fileInputRef = useRef(null);

  const refresh = useCallback(async () => {
    const data = await loadTeamMessages();
    setMessages(data);
  }, []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    refresh().then(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [refresh]);

  useEffect(() => {
    if (!isUsingSupabase) return undefined;
    const interval = setInterval(refresh, 4000);
    return () => clearInterval(interval);
  }, [refresh]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length]);

  const pickVideo = () => fileInputRef.current?.click();

  const handleVideoSelected = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setUploading(true);
    const url = await uploadChatVideo(file, selfId);
    setUploading(false);
    if (url) setPendingVideo({ url, name: file.name });
  };

  const submit = async () => {
    const text = draft.trim();
    if ((!text && !pendingVideo) || sending) return;
    setSending(true);
    const videoUrl = pendingVideo?.url || null;
    setDraft("");
    setPendingVideo(null);
    const optimistic = { id: `pending-${Date.now()}`, sender_id: selfId, sender_name: selfName, body: text, video_url: videoUrl, created_at: new Date().toISOString() };
    setMessages((prev) => [...prev, optimistic]);
    await sendTeamMessage(selfId, selfName, text, videoUrl);
    await refresh();
    setSending(false);
  };

  return (
    <div className="flex flex-col" style={{ minHeight: "50vh" }}>
      <div className="mb-3 rounded-lg px-3 py-2.5 flex items-start gap-2" style={{ backgroundColor: "#1B252D", border: "1px solid #263139" }}>
        <Megaphone size={14} className="flex-shrink-0 mt-0.5" style={{ color: "#C9A15F" }} />
        <p className="text-[14px] leading-snug" style={{ color: "#AEBEC8" }}>
          {readOnly
            ? "Announcements from your coach — schedule changes, general news, that kind of thing."
            : "Everyone on the team sees this channel — coach and all clients. Good for announcements, schedule changes, or general news."}
        </p>
      </div>

      {!isUsingSupabase && (
        <div className="mb-3 rounded-lg px-3 py-2 text-[13.5px]" style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#8FA0AC" }}>
          No Supabase connection — posts only stay on this device for now, and video uploads are unavailable until Supabase Storage is connected.
        </div>
      )}

      <div className="flex-1 space-y-2.5 mb-3">
        {loading && <div className="text-center py-8 bp-mono text-xs" style={{ color: "#5C6D78" }}>Loading…</div>}

        {!loading && messages.length === 0 && (
          <div className="rounded-lg p-6 text-center" style={{ border: "1px solid #263139" }}>
            <p className="bp-mono text-xs uppercase tracking-widest mb-1" style={{ color: "#5C6D78" }}>No Posts Yet</p>
            <p className="text-sm" style={{ color: "#8FA0AC" }}>{readOnly ? "Nothing posted yet — check back soon." : "Post the first update below."}</p>
          </div>
        )}

        {!loading && messages.map((m) => {
          const mine = m.sender_id === selfId;
          return (
            <div key={m.id} className="flex" style={{ justifyContent: mine ? "flex-end" : "flex-start" }}>
              <div className="max-w-[78%] rounded-lg px-3 py-2" style={{ backgroundColor: mine ? accent : "#1B252D", border: mine ? "none" : "1px solid #263139" }}>
                {!mine && (
                  <div className="bp-mono text-[11px] uppercase tracking-wide mb-0.5" style={{ color: m.sender_id === "coach" ? "#C9A15F" : "#8FA0AC" }}>
                    {m.sender_name}{m.sender_id === "coach" ? " · Coach" : ""}
                  </div>
                )}
                {m.video_url && (
                  <button
                    onClick={() => setPlayingVideo({ url: m.video_url, title: m.sender_name })}
                    className="relative flex items-center justify-center rounded-lg mb-1.5 overflow-hidden"
                    style={{ width: 180, height: 100, backgroundColor: "#000" }}
                  >
                    <video src={m.video_url} className="w-full h-full object-cover" muted />
                    <div className="absolute inset-0 flex items-center justify-center" style={{ backgroundColor: "#00000055" }}>
                      <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ backgroundColor: "#EDF1F4dd" }}>
                        <Video size={16} color="#12191F" />
                      </div>
                    </div>
                  </button>
                )}
                {m.body && <div className="text-[15px] leading-snug whitespace-pre-wrap" style={{ color: mine ? "#12191F" : "#EDF1F4" }}>{m.body}</div>}
                <div className="bp-mono text-[11px] mt-1" style={{ color: mine ? "#12191F99" : "#5C6D78" }}>{formatMsgTime(m.created_at)}</div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {readOnly ? (
        <div className="text-center bp-mono text-[12px] uppercase tracking-widest py-2" style={{ color: "#5C6D78" }}>
          Only your coach posts here
        </div>
      ) : (
        <>
          {pendingVideo && (
            <div className="flex items-center gap-2 mb-2 px-3 py-2 rounded-lg" style={{ backgroundColor: "#1B252D", border: `1px solid ${accent}55` }}>
              <Video size={14} style={{ color: accent }} />
              <span className="flex-1 text-[13px] truncate" style={{ color: "#AEBEC8" }}>{pendingVideo.name}</span>
              <button onClick={() => setPendingVideo(null)} aria-label="Remove attached video" style={{ color: "#8FA0AC" }}>
                <X size={14} />
              </button>
            </div>
          )}
          <div className="sticky bottom-0 flex items-end gap-2 pt-2" style={{ backgroundColor: "#12191F" }}>
            <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={handleVideoSelected} />
            <button
              onClick={pickVideo}
              disabled={uploading || !isUsingSupabase}
              aria-label="Attach a video"
              className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center"
              style={{ border: "1px solid #263139", color: isUsingSupabase ? "#8FA0AC" : "#3A4750" }}
            >
              {uploading ? <span className="bp-mono text-[9px]">…</span> : <Paperclip size={16} />}
            </button>
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } }}
              placeholder="Post to the team channel…"
              rows={1}
              className="flex-1 text-[15px] rounded-lg px-3 py-2.5 resize-none"
              style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#EDF1F4", maxHeight: 100 }}
            />
            <button
              onClick={submit}
              disabled={(!draft.trim() && !pendingVideo) || sending}
              aria-label="Post to team channel"
              className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: draft.trim() || pendingVideo ? accent : "#263139", color: draft.trim() || pendingVideo ? "#12191F" : "#5C6D78" }}
            >
              <Send size={16} />
            </button>
          </div>
        </>
      )}

      {playingVideo && <VideoModal url={playingVideo.url} title={playingVideo.title} onClose={() => setPlayingVideo(null)} />}
    </div>
  );
}

/* ============================================================================
   NOTIFICATION PROMPT — small dismissible banner offering to turn on push.
   Only renders anything meaningful once VITE_VAPID_PUBLIC_KEY is set; before
   that, push is quietly unavailable rather than half-working.
============================================================================ */
function NotificationPrompt({ ownerId }) {
  const [status, setStatus] = useState("checking"); // checking | hidden | offer | enabled | denied
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!pushConfigured) { setStatus("hidden"); return; }
      const permission = getNotificationPermission();
      if (permission === "denied") { setStatus("denied"); return; }
      const enabled = await isPushEnabled();
      if (cancelled) return;
      if (enabled) setStatus("enabled");
      else setStatus("offer");
    })();
    return () => { cancelled = true; };
  }, []);

  if (status === "checking" || status === "hidden") return null;

  const enable = async () => {
    setBusy(true);
    const ok = await enablePushNotifications(ownerId);
    setBusy(false);
    setStatus(ok ? "enabled" : "denied");
  };

  if (status === "enabled") {
    return (
      <div className="flex items-center gap-2 rounded-lg px-3 py-2 text-[13.5px] mb-3" style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#8FA0AC" }}>
        <Bell size={13} style={{ color: "#6FB35C" }} /> Notifications on for this device.
      </div>
    );
  }

  if (status === "denied") {
    return (
      <div className="flex items-center gap-2 rounded-lg px-3 py-2 text-[13.5px] mb-3" style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#8FA0AC" }}>
        <BellOff size={13} /> Notifications are blocked for this site in your browser settings.
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between gap-3 rounded-lg px-3 py-2.5 mb-3" style={{ backgroundColor: "#1B252D", border: "1px solid #263139" }}>
      <div className="flex items-center gap-2 min-w-0">
        <Bell size={14} className="flex-shrink-0" style={{ color: "#C9A15F" }} />
        <span className="text-[14px] leading-snug" style={{ color: "#AEBEC8" }}>Get notified when a new message comes in.</span>
      </div>
      <button onClick={enable} disabled={busy} className="flex-shrink-0 bp-mono text-[12px] uppercase tracking-widest px-2.5 py-1.5 rounded-lg" style={{ backgroundColor: "#C9A15F", color: "#12191F" }}>
        {busy ? "…" : "Enable"}
      </button>
    </div>
  );
}
/* END NotificationPrompt */

/* ============================================================================
   WEEK EDITOR — coach-only. Add or edit a week's focus + blocks + drills for
   one client/domain, right from the app. Saves to Supabase (or localStorage
   in local-only mode) via program_weeks / storage.js.
============================================================================ */
function emptyBlock() {
  return { _key: nextUid(), title: "", items: [emptyItem()] };
}
function emptyItem() {
  return { _key: nextUid(), name: "", detail: "", cue: "", video: "" };
}

function WeekEditor({ clientId, domain, domainLabel, accent, weekStart, initialData, onClose, onSaved, onDeleted }) {
  const [focus, setFocus] = useState(initialData?.focus || "");
  const [blocks, setBlocks] = useState(() => {
    const source = initialData?.blocks?.length ? initialData.blocks : [emptyBlock()];
    return source.map((b) => ({
      _key: nextUid(),
      title: b.title || "",
      items: (b.items?.length ? b.items : [emptyItem()]).map((it) => ({ _key: nextUid(), ...it })),
    }));
  });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const updateBlockTitle = (bi, title) => setBlocks((prev) => prev.map((b, i) => (i === bi ? { ...b, title } : b)));
  const updateItem = (bi, ii, field, value) =>
    setBlocks((prev) => prev.map((b, i) => (i !== bi ? b : { ...b, items: b.items.map((it, j) => (j === ii ? { ...it, [field]: value } : it)) })));
  const addItem = (bi) => setBlocks((prev) => prev.map((b, i) => (i === bi ? { ...b, items: [...b.items, emptyItem()] } : b)));
  const removeItem = (bi, ii) => setBlocks((prev) => prev.map((b, i) => (i !== bi ? b : { ...b, items: b.items.filter((_, j) => j !== ii) })));
  const addBlock = () => setBlocks((prev) => [...prev, emptyBlock()]);
  const removeBlock = (bi) => setBlocks((prev) => prev.filter((_, i) => i !== bi));

  const save = async () => {
    setSaving(true);
    const cleanBlocks = blocks
      .map((b) => ({
        title: b.title.trim(),
        items: b.items
          .map((it) => ({ name: it.name.trim(), detail: it.detail.trim(), cue: it.cue.trim(), video: it.video?.trim() || "" }))
          .filter((it) => it.name),
      }))
      .filter((b) => b.title && b.items.length > 0);

    const ok = await saveProgramWeek(clientId, domain, weekStart, { focus: focus.trim() || undefined, blocks: cleanBlocks });
    setSaving(false);
    if (ok) onSaved();
  };

  const remove = async () => {
    setSaving(true);
    const ok = await deleteProgramWeek(clientId, domain, weekStart);
    setSaving(false);
    if (ok) onDeleted();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" style={{ backgroundColor: "#12191F" }}>
      <header className="sticky top-0 z-10" style={{ backgroundColor: "#12191Fcc", backdropFilter: "blur(6px)", borderBottom: "1px solid #263139" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <button onClick={onClose} aria-label="Cancel" className="p-1 -ml-1 rounded-lg flex-shrink-0" style={{ color: "#8FA0AC" }}>
              <X size={18} />
            </button>
            <div className="min-w-0">
              <div className="bp-mono text-[12px] tracking-[0.25em] uppercase" style={{ color: "#8FA0AC" }}>Editing — {domainLabel}</div>
              <h1 className="bp-display text-base sm:text-lg font-semibold uppercase tracking-wide">{formatDayLabel(weekStart)}</h1>
            </div>
          </div>
          <button onClick={save} disabled={saving} className="flex-shrink-0 bp-mono text-[13px] uppercase tracking-widest px-3 py-2 rounded-lg" style={{ backgroundColor: accent, color: "#12191F" }}>
            {saving ? "Saving…" : "Save"}
          </button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-5 pb-20">
        <label className="bp-mono text-[12px] uppercase tracking-widest block mb-1.5" style={{ color: "#8FA0AC" }}>Focus for this week (optional)</label>
        <input
          type="text"
          value={focus}
          onChange={(e) => setFocus(e.target.value)}
          placeholder="e.g. Add rotation control on top of the breathing base"
          className="w-full text-[15.5px] rounded-lg px-3 py-2.5 mb-5"
          style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#EDF1F4" }}
        />

        <div className="space-y-4">
          {blocks.map((block, bi) => (
            <div key={block._key} className="rounded-lg overflow-hidden" style={{ backgroundColor: "#161F26", border: "1px solid #22303A" }}>
              <div className="flex items-center gap-2 px-3 py-2.5" style={{ backgroundColor: "#1B252D", borderBottom: "1px solid #22303A" }}>
                <input
                  type="text"
                  value={block.title}
                  onChange={(e) => updateBlockTitle(bi, e.target.value)}
                  placeholder="Block title (e.g. Dynamic Warm-Up)"
                  className="flex-1 bp-mono text-[13px] uppercase tracking-widest bg-transparent outline-none"
                  style={{ color: accent }}
                />
                {blocks.length > 1 && (
                  <button onClick={() => removeBlock(bi)} aria-label="Remove block" className="flex-shrink-0 p-1" style={{ color: "#5C6D78" }}>
                    <Trash2 size={13} />
                  </button>
                )}
              </div>
              <div className="p-3 space-y-3">
                {block.items.map((item, ii) => (
                  <div key={item._key} className="rounded-lg p-2.5 space-y-2" style={{ border: "1px solid #1E2A32" }}>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={item.name}
                        onChange={(e) => updateItem(bi, ii, "name", e.target.value)}
                        placeholder="Drill name"
                        className="flex-1 text-[15px] rounded-lg px-2.5 py-1.5"
                        style={{ backgroundColor: "#12191F", border: "1px solid #263139", color: "#EDF1F4" }}
                      />
                      {block.items.length > 1 && (
                        <button onClick={() => removeItem(bi, ii)} aria-label="Remove drill" className="flex-shrink-0 p-1" style={{ color: "#5C6D78" }}>
                          <X size={14} />
                        </button>
                      )}
                    </div>
                    <input
                      type="text"
                      value={item.detail}
                      onChange={(e) => updateItem(bi, ii, "detail", e.target.value)}
                      placeholder="Sets/reps (e.g. 3 x 8/side)"
                      className="w-full bp-mono text-[13.5px] rounded-lg px-2.5 py-1.5"
                      style={{ backgroundColor: "#12191F", border: "1px solid #263139", color: "#EDF1F4" }}
                    />
                    <input
                      type="text"
                      value={item.cue}
                      onChange={(e) => updateItem(bi, ii, "cue", e.target.value)}
                      placeholder="Coaching cue (optional)"
                      className="w-full text-[14.5px] rounded-lg px-2.5 py-1.5"
                      style={{ backgroundColor: "#12191F", border: "1px solid #263139", color: "#EDF1F4" }}
                    />
                    <input
                      type="text"
                      value={item.video}
                      onChange={(e) => updateItem(bi, ii, "video", e.target.value)}
                      placeholder="Demo video URL (optional, direct .mp4 link)"
                      className="w-full text-[14.5px] rounded-lg px-2.5 py-1.5"
                      style={{ backgroundColor: "#12191F", border: "1px solid #263139", color: "#EDF1F4" }}
                    />
                  </div>
                ))}
                <button onClick={() => addItem(bi)} className="flex items-center gap-1.5 bp-mono text-[12px] uppercase tracking-widest px-2 py-1.5" style={{ color: accent }}>
                  <Plus size={13} /> Add Drill
                </button>
              </div>
            </div>
          ))}
        </div>

        <button onClick={addBlock} className="w-full flex items-center justify-center gap-1.5 mt-4 py-2.5 rounded-lg bp-mono text-[13px] uppercase tracking-widest" style={{ border: "1px dashed #263139", color: "#8FA0AC" }}>
          <Plus size={14} /> Add Block
        </button>

        {initialData && (
          <div className="mt-8 pt-5" style={{ borderTop: "1px solid #263139" }}>
            {!confirmDelete ? (
              <button onClick={() => setConfirmDelete(true)} className="flex items-center gap-1.5 bp-mono text-[13px] uppercase tracking-widest" style={{ color: "#D9603B" }}>
                <Trash2 size={13} /> Delete This Week
              </button>
            ) : (
              <div className="flex items-center gap-3">
                <span className="text-[14.5px]" style={{ color: "#8FA0AC" }}>Delete this week's programming?</span>
                <button onClick={remove} disabled={saving} className="bp-mono text-[12px] uppercase tracking-widest px-2.5 py-1.5 rounded-lg" style={{ backgroundColor: "#D9603B", color: "#EDF1F4" }}>
                  Confirm
                </button>
                <button onClick={() => setConfirmDelete(false)} className="bp-mono text-[12px] uppercase tracking-widest" style={{ color: "#5C6D78" }}>
                  Cancel
                </button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

/* ============================================================================
   READINESS CHECK-IN — quick daily sleep/soreness/energy self-report,
   shown once per day before a client's program.
============================================================================ */
function RatingRow({ label, icon: Icon, value, onChange, accent }) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-1.5 mb-2">
        <Icon size={13} style={{ color: accent }} />
        <span className="bp-mono text-[12px] uppercase tracking-widest" style={{ color: "#8FA0AC" }}>{label}</span>
      </div>
      <div className="flex gap-1.5">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            onClick={() => onChange(n)}
            className="flex-1 py-2.5 rounded-lg bp-mono text-[15px] font-medium"
            style={{ backgroundColor: value === n ? accent : "#1B252D", color: value === n ? "#12191F" : "#8FA0AC", border: `1px solid ${value === n ? accent : "#263139"}` }}
          >
            {n}
          </button>
        ))}
      </div>
    </div>
  );
}

function ReadinessCheckin({ clientId, onDone, onSkip }) {
  const [sleep, setSleep] = useState(null);
  const [soreness, setSoreness] = useState(null);
  const [energy, setEnergy] = useState(null);
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    if (!sleep || !soreness || !energy) return;
    setSaving(true);
    await saveCheckin(clientId, todayStr(), { sleep, soreness, energy });
    setSaving(false);
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center px-4 pb-4 sm:pb-0" style={{ backgroundColor: "#0A0E12dd" }}>
      <div className="w-full max-w-sm rounded-lg p-5" style={{ backgroundColor: "#161F26", border: "1px solid #263139" }}>
        <h2 className="bp-display text-base uppercase tracking-wide mb-1">Quick Check-In</h2>
        <p className="text-[14.5px] mb-4" style={{ color: "#8FA0AC" }}>Rate each 1 (worst) to 5 (best) before today's training.</p>

        <RatingRow label="Sleep" icon={Moon} value={sleep} onChange={setSleep} accent="#5FB8A6" />
        <RatingRow label="Soreness (5 = fresh)" icon={AlertTriangle} value={soreness} onChange={setSoreness} accent="#E0A63B" />
        <RatingRow label="Energy" icon={Battery} value={energy} onChange={setEnergy} accent="#4C93D0" />

        <div className="flex items-center gap-2 mt-2">
          <button onClick={onSkip} className="flex-1 py-2.5 rounded-lg bp-mono text-[13px] uppercase tracking-widest" style={{ border: "1px solid #263139", color: "#8FA0AC" }}>
            Skip Today
          </button>
          <button
            onClick={submit}
            disabled={!sleep || !soreness || !energy || saving}
            className="flex-1 py-2.5 rounded-lg bp-mono text-[13px] uppercase tracking-widest"
            style={{ backgroundColor: sleep && soreness && energy ? "#C9A15F" : "#263139", color: sleep && soreness && energy ? "#12191F" : "#5C6D78" }}
          >
            {saving ? "…" : "Submit"}
          </button>
        </div>
      </div>
    </div>
  );
}
export default function App() {
  const urlClientId = getUrlParam("client");
  const urlCoachFlag = getUrlParam("coach") === "1";
  // Coach dashboard sets only `coach=1`. A client's own link sets only
  // `client=id`. When BOTH are present, that means the coach opened this
  // specific client from their dashboard (see openClientDirect below) —
  // keeping both params in the URL (rather than clearing `coach`) is what
  // lets a page refresh remember "I'm the coach looking at this client"
  // instead of silently falling back to treating it as the client's own
  // PIN-gated link and hiding coach-only controls like Edit.
  const coachViewingClientKey = urlCoachFlag && urlClientId && CLIENTS[urlClientId] ? urlClientId : null;

  const [coachAuthed, setCoachAuthedState] = useState(sessionStorage.getItem("bp-coach-authed") === "1");
  const [wantsCoach, setWantsCoach] = useState(urlCoachFlag);
  const [viewingAsCoach, setViewingAsCoach] = useState(!!coachViewingClientKey);
  const [pendingClientId, setPendingClientId] = useState(
    !coachViewingClientKey && urlClientId && CLIENTS[urlClientId] ? urlClientId : null
  );
  const [activeClientId, setActiveClientId] = useState(() => {
    if (coachViewingClientKey && coachAuthed) return coachViewingClientKey;
    if (urlClientId && CLIENTS[urlClientId] && isAuthed(urlClientId)) return urlClientId;
    return null;
  });
  const [clientsVersion, setClientsVersion] = useState(0); // bumped whenever CLIENTS is mutated, to force a re-render

  // Load any clients added via the in-app "+ Add Client" form and merge
  // them into the static CLIENTS roster from clients.js. Mutating CLIENTS
  // in place (rather than replacing it) keeps every existing `CLIENTS[id]`
  // lookup elsewhere in the app working unchanged.
  useEffect(() => {
    let cancelled = false;
    loadDynamicClients().then((rows) => {
      if (cancelled) return;
      let changed = false;
      Object.entries(rows).forEach(([key, { name, pin }]) => {
        if (!CLIENTS[key]) {
          CLIENTS[key] = { name, pin, programs: buildEmptyPrograms() };
          changed = true;
        }
      });
      if (changed) setClientsVersion((v) => v + 1);
    });
    return () => { cancelled = true; };
  }, []);

  // If someone opened a direct link to a client added dynamically, the URL
  // lookup above ran before that client existed in CLIENTS — re-check once
  // the merge finishes.
  useEffect(() => {
    if (clientsVersion === 0) return;
    if (activeClientId) return;
    if (coachViewingClientKey && CLIENTS[coachViewingClientKey] && coachAuthed) {
      setActiveClientId(coachViewingClientKey);
      setViewingAsCoach(true);
      return;
    }
    if (!urlClientId || !CLIENTS[urlClientId] || pendingClientId) return;
    if (isAuthed(urlClientId)) setActiveClientId(urlClientId);
    else setPendingClientId(urlClientId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clientsVersion]);

  const createNewClient = useCallback(async (key, name, pin) => {
    const ok = await createClient(key, name, pin);
    if (ok) {
      CLIENTS[key] = { name, pin, programs: buildEmptyPrograms() };
      setClientsVersion((v) => v + 1);
    }
    return ok;
  }, []);

  const goToSelect = () => {
    setPendingClientId(null);
    setActiveClientId(null);
    setWantsCoach(false);
    setViewingAsCoach(false);
    setUrlParam("client", null);
    setUrlParam("coach", null);
  };

  const goToCoach = () => {
    setWantsCoach(true);
    setActiveClientId(null);
    setViewingAsCoach(false);
    setUrlParam("client", null);
    setUrlParam("coach", "1");
  };

  const loginWithNameAndPin = (id) => {
    setAuthed(id);
    setActiveClientId(id);
    setViewingAsCoach(false);
    setWantsCoach(false);
    setUrlParam("client", id);
    setUrlParam("coach", null);
  };

  const openClientDirect = (id) => {
    // used from the coach dashboard — coach doesn't need the client's PIN.
    // Keep BOTH url params (not just `client`) so a refresh still knows
    // this is the coach, not the client — see coachViewingClientKey above.
    setActiveClientId(id);
    setViewingAsCoach(true);
    setWantsCoach(false);
    setUrlParam("client", id);
    setUrlParam("coach", "1");
  };

  // Render order matters: resolve an active client session (including the
  // coach-viewing-a-client case) BEFORE the plain coach dashboard, so a
  // URL carrying both `client` and `coach` goes straight to that client
  // instead of the dashboard.
  if (activeClientId && CLIENTS[activeClientId]) {
    return (
      <ClientProgram
        clientId={activeClientId}
        clientData={CLIENTS[activeClientId]}
        isCoachView={viewingAsCoach}
        onBack={goToSelect}
        onCoach={goToCoach}
      />
    );
  }

  if (wantsCoach) {
    if (!coachAuthed) {
      return (
        <PinGate
          clientName="Coach Access"
          pin={COACH_PIN}
          showHint={!import.meta.env.VITE_COACH_PIN}
          onBack={goToSelect}
          onSuccess={() => {
            sessionStorage.setItem("bp-coach-authed", "1");
            setCoachAuthedState(true);
            // Arrived via a coach-viewing-client link (e.g. a bookmarked
            // or shared URL) — go straight to that client once authed,
            // instead of landing on the dashboard first.
            if (coachViewingClientKey) {
              setActiveClientId(coachViewingClientKey);
              setViewingAsCoach(true);
            }
          }}
        />
      );
    }
    return <CoachDashboard onBack={goToSelect} onOpenClient={openClientDirect} onCreateClient={createNewClient} />;
  }

  if (pendingClientId && CLIENTS[pendingClientId]) {
    const c = CLIENTS[pendingClientId];
    return (
      <PinGate
        clientName={c.name}
        pin={c.pin}
        onBack={goToSelect}
        onSuccess={() => {
          setAuthed(pendingClientId);
          setActiveClientId(pendingClientId);
        }}
      />
    );
  }

  return <LoginForm attempted={urlClientId} onLogin={loginWithNameAndPin} onCoach={goToCoach} />;
}

/* ============================================================================
   CLIENT SELECT — fallback/testing screen. In production each client should
   go straight to their own link (yoursite.com/?client=their-id) and never
   see this screen at all.
============================================================================ */
function LoginForm({ attempted, onLogin, onCoach }) {
  const [name, setName] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  const submit = () => {
    setError("");
    const trimmedName = name.trim().toLowerCase();
    if (!trimmedName || pin.length !== 4) {
      setError("Enter your name and 4-digit PIN.");
      return;
    }
    const match = Object.entries(CLIENTS).find(
      ([, c]) => c.name.trim().toLowerCase() === trimmedName && c.pin === pin
    );
    if (!match) {
      setError("That name and PIN don't match. Double-check with your coach.");
      return;
    }
    onLogin(match[0]);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 relative overflow-hidden" style={{ backgroundColor: "#0F151B", color: "#EDF1F4" }}>
      <div
        aria-hidden="true"
        className="absolute pointer-events-none"
        style={{
          top: "-20%",
          left: "50%",
          transform: "translateX(-50%)",
          width: 520,
          height: 520,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(201,161,95,0.16) 0%, rgba(201,161,95,0) 70%)",
        }}
      />
      <div className="w-full max-w-sm relative">
        <div className="flex flex-col items-center mb-8">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
            style={{ background: "linear-gradient(135deg, #C9A15F 0%, #A9803F 100%)", boxShadow: "0 8px 24px rgba(201,161,95,0.25)" }}
          >
            <span className="bp-display text-xl font-bold" style={{ color: "#12191F" }}>JY</span>
          </div>
          <h1 className="bp-display text-2xl font-semibold tracking-wide">JYPerformance</h1>
          <p className="bp-mono text-[12px] uppercase tracking-[0.2em] mt-1" style={{ color: "#5C6D78" }}>Training Portal</p>
        </div>

        <div className="rounded-2xl p-5" style={{ backgroundColor: "#161F26", border: "1px solid #263139" }}>
          {attempted && !CLIENTS[attempted] && (
            <p className="text-[15px] mb-3" style={{ color: "#D9603B" }}>No program found for "{attempted}" — log in below instead.</p>
          )}

          <label className="bp-mono text-[12px] uppercase tracking-widest block mb-1.5" style={{ color: "#8FA0AC" }}>Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => { setError(""); setName(e.target.value); }}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="Your first name"
            autoFocus
            className="w-full text-[16px] rounded-xl px-3.5 py-3 mb-4"
            style={{ backgroundColor: "#12191F", border: "1px solid #263139", color: "#EDF1F4" }}
          />

          <label className="bp-mono text-[12px] uppercase tracking-widest block mb-1.5" style={{ color: "#8FA0AC" }}>PIN</label>
          <input
            type="password"
            inputMode="numeric"
            maxLength={4}
            value={pin}
            onChange={(e) => { setError(""); setPin(e.target.value.replace(/\D/g, "").slice(0, 4)); }}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="4-digit PIN"
            className="w-full text-[16px] tracking-[0.4em] rounded-xl px-3.5 py-3 mb-2"
            style={{ backgroundColor: "#12191F", border: "1px solid #263139", color: "#EDF1F4" }}
          />

          {error && <p className="text-[14px] mt-2 mb-1" style={{ color: "#D9603B" }}>{error}</p>}

          <button
            onClick={submit}
            disabled={!name.trim() || pin.length !== 4}
            className="w-full py-3 rounded-xl bp-mono text-[13px] uppercase tracking-widest mt-3"
            style={{ backgroundColor: name.trim() && pin.length === 4 ? "#C9A15F" : "#263139", color: name.trim() && pin.length === 4 ? "#12191F" : "#5C6D78" }}
          >
            Log In
          </button>
        </div>

        <button onClick={onCoach} className="w-full flex items-center justify-center gap-2 px-4 py-3 mt-4 rounded-xl bp-mono text-[13px] uppercase tracking-widest" style={{ border: "1px dashed #263139", color: "#8FA0AC" }}>
          <Users size={14} /> Coach Login
        </button>
      </div>
    </div>
  );
}

/* ============================================================================
   PIN GATE
============================================================================ */
function PinGate({ clientName, pin, onSuccess, onBack, showHint }) {
  const [value, setValue] = useState("");
  const [error, setError] = useState(false);

  const submit = () => {
    if (value === pin) onSuccess();
    else {
      setError(true);
      setValue("");
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4" style={{ backgroundColor: "#12191F", color: "#EDF1F4" }}>
      <div className="w-full max-w-xs text-center">
        <button onClick={onBack} className="flex items-center gap-1.5 bp-mono text-[12px] uppercase tracking-wide mx-auto mb-6" style={{ color: "#5C6D78" }}>
          <ArrowLeft size={12} /> Back
        </button>
        <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: "#1B252D", border: "1px solid #263139" }}>
          <Lock size={18} color="#C9A15F" />
        </div>
        <h1 className="bp-display text-lg uppercase tracking-wide mb-1">{clientName}</h1>
        <p className="text-[15px] mb-5" style={{ color: "#8FA0AC" }}>Enter your 4-digit PIN</p>
        <input
          type="tel"
          inputMode="numeric"
          maxLength={4}
          value={value}
          onChange={(e) => { setError(false); setValue(e.target.value.replace(/\D/g, "")); }}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          autoFocus
          className="w-full text-center text-2xl tracking-[0.5em] rounded-lg px-3 py-3 mb-2 bp-mono"
          style={{ backgroundColor: "#1B252D", border: `1px solid ${error ? "#D9603B" : "#263139"}`, color: "#EDF1F4" }}
          placeholder="••••"
        />
        {error && <p className="text-[14px] mb-3" style={{ color: "#D9603B" }}>Incorrect PIN — try again</p>}
        <button
          onClick={submit}
          disabled={value.length !== 4}
          className="w-full py-2.5 rounded-lg bp-mono text-[14px] uppercase tracking-widest mt-2"
          style={{ backgroundColor: value.length === 4 ? "#C9A15F" : "#263139", color: value.length === 4 ? "#12191F" : "#5C6D78" }}
        >
          Unlock
        </button>
        {showHint && (
          <p className="bp-mono text-[12px] mt-4" style={{ color: "#3A4750" }}>
            No VITE_COACH_PIN set — using default {pin}. Set one before sending this live.
          </p>
        )}
      </div>
    </div>
  );
}

/* ============================================================================
   COACH DASHBOARD
============================================================================ */
function computeClientSummary(clientData, logs) {
  let totalItems = 0;
  DOMAIN_KEYS.forEach((dk) => {
    const domain = clientData.programs[dk];
    Object.values(domain?.weeks || {}).forEach((wk) => {
      wk.blocks.forEach((b) => (totalItems += b.items.length));
    });
  });
  const entries = Object.values(logs || {});
  const doneItems = entries.length;
  const lastActive = entries.reduce((max, e) => (!max || e.date > max ? e.date : max), null);
  const pct = totalItems ? Math.round((doneItems / totalItems) * 100) : 0;
  return { totalItems, doneItems, pct, lastActive };
}

/* ============================================================================
   ADD CLIENT — lets the coach add a new client from inside the app instead
   of hand-editing clients.js and redeploying. Saves via storage.js
   (Supabase `clients` table, localStorage fallback in local-only mode).
============================================================================ */
function AddClientForm({ onBack, onCreate }) {
  const [name, setName] = useState("");
  const [pin, setPin] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const slug = slugifyName(name);

  const submit = async () => {
    setError("");
    if (!name.trim()) { setError("Enter a name"); return; }
    if (!slug) { setError("Name needs at least one letter or number"); return; }
    if (CLIENTS[slug]) { setError("A client with a matching name/link already exists — try adding a last initial"); return; }
    if (!/^\d{4}$/.test(pin)) { setError("PIN must be exactly 4 digits"); return; }
    setSaving(true);
    const ok = await onCreate(slug, name.trim(), pin);
    setSaving(false);
    if (!ok) setError("Couldn't save that client — try again");
  };

  return (
    <div className="min-h-screen w-full" style={{ backgroundColor: "#12191F", color: "#EDF1F4" }}>
      <header className="sticky top-0 z-20" style={{ backgroundColor: "#12191Fcc", backdropFilter: "blur(6px)", borderBottom: "1px solid #263139" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-2">
          <button onClick={onBack} aria-label="Back" className="p-1 -ml-1 rounded-lg" style={{ color: "#8FA0AC" }}>
            <ArrowLeft size={16} />
          </button>
          <div>
            <div className="bp-mono text-[12px] tracking-[0.25em] uppercase" style={{ color: "#8FA0AC" }}>New Client</div>
            <h1 className="bp-display text-lg sm:text-xl font-semibold uppercase tracking-wide">Add Client</h1>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-5 max-w-sm">
        <label className="bp-mono text-[12px] uppercase tracking-widest block mb-1.5" style={{ color: "#8FA0AC" }}>Name</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Maria Alvarez"
          autoFocus
          className="w-full text-[16px] rounded-lg px-3 py-2.5 mb-1"
          style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#EDF1F4" }}
        />
        {slug && (
          <p className="bp-mono text-[12px] mb-4" style={{ color: "#5C6D78" }}>Link key: <span style={{ color: "#8FA0AC" }}>{slug}</span></p>
        )}

        <label className="bp-mono text-[12px] uppercase tracking-widest block mb-1.5 mt-3" style={{ color: "#8FA0AC" }}>4-digit PIN</label>
        <input
          type="tel"
          inputMode="numeric"
          maxLength={4}
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
          placeholder="e.g. 4471"
          className="w-full text-[16px] tracking-[0.3em] rounded-lg px-3 py-2.5 mb-4"
          style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#EDF1F4" }}
        />

        {error && <p className="text-[14.5px] mb-3" style={{ color: "#D9603B" }}>{error}</p>}

        <button
          onClick={submit}
          disabled={saving || !name.trim() || pin.length !== 4}
          className="w-full py-2.5 rounded-lg bp-mono text-[14px] uppercase tracking-widest"
          style={{ backgroundColor: name.trim() && pin.length === 4 ? "#C9A15F" : "#263139", color: name.trim() && pin.length === 4 ? "#12191F" : "#5C6D78" }}
        >
          {saving ? "Creating…" : "Create Client"}
        </button>

        <p className="text-[14px] mt-4" style={{ color: "#5C6D78" }}>
          After creating, open their program from the dashboard to write their first week. Send them <span style={{ color: "#8FA0AC" }}>yoursite.com/?client={slug || "…"}</span> + their PIN once it's ready.
        </p>
      </main>
    </div>
  );
}

function CoachDashboard({ onBack, onOpenClient, onCreateClient }) {
  const ids = Object.keys(CLIENTS);
  const [allLogs, setAllLogs] = useState(null);
  const [msgSummaries, setMsgSummaries] = useState({});
  const [checkinSummaries, setCheckinSummaries] = useState({});
  const [messagingClientId, setMessagingClientId] = useState(null);
  const [showTeamChannel, setShowTeamChannel] = useState(false);
  const [showAddClient, setShowAddClient] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("name"); // name | quiet | unread

  const refreshSummaries = useCallback(() => {
    loadMessageSummaries(ids).then(setMsgSummaries);
    loadTodayCheckinSummaries(ids, todayStr()).then(setCheckinSummaries);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let cancelled = false;
    loadAllClientLogs(ids).then((data) => {
      if (!cancelled) setAllLogs(data);
    });
    refreshSummaries();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!isUsingSupabase) return undefined;
    const interval = setInterval(refreshSummaries, 5000);
    return () => clearInterval(interval);
  }, [refreshSummaries]);

  // Re-check unread counts once the coach closes a thread they were reading
  useEffect(() => {
    if (messagingClientId === null) refreshSummaries();
  }, [messagingClientId, refreshSummaries]);

  if (showAddClient) {
    return (
      <AddClientForm
        onBack={() => setShowAddClient(false)}
        onCreate={async (key, name, pin) => {
          const ok = await onCreateClient(key, name, pin);
          if (ok) setShowAddClient(false);
          return ok;
        }}
      />
    );
  }

  if (showTeamChannel) {
    return (
      <div className="min-h-screen w-full" style={{ backgroundColor: "#12191F", color: "#EDF1F4" }}>
        <header className="sticky top-0 z-20" style={{ backgroundColor: "#12191Fcc", backdropFilter: "blur(6px)", borderBottom: "1px solid #263139" }}>
          <div className="max-w-3xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-2">
            <button onClick={() => setShowTeamChannel(false)} aria-label="Back to dashboard" className="p-1 -ml-1 rounded-lg" style={{ color: "#8FA0AC" }}>
              <ArrowLeft size={16} />
            </button>
            <div>
              <div className="bp-mono text-[12px] tracking-[0.25em] uppercase" style={{ color: "#8FA0AC" }}>Team Channel</div>
              <h1 className="bp-display text-lg sm:text-xl font-semibold uppercase tracking-wide">Everyone</h1>
            </div>
          </div>
        </header>
        <main className="max-w-3xl mx-auto px-4 sm:px-6 py-5">
          <NotificationPrompt ownerId="coach" />
          <TeamChannel selfId="coach" selfName="Coach" />
        </main>
      </div>
    );
  }

  if (messagingClientId && CLIENTS[messagingClientId]) {
    return (
      <div className="min-h-screen w-full" style={{ backgroundColor: "#12191F", color: "#EDF1F4" }}>
        <header className="sticky top-0 z-20" style={{ backgroundColor: "#12191Fcc", backdropFilter: "blur(6px)", borderBottom: "1px solid #263139" }}>
          <div className="max-w-3xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-2">
            <button onClick={() => setMessagingClientId(null)} aria-label="Back to dashboard" className="p-1 -ml-1 rounded-lg" style={{ color: "#8FA0AC" }}>
              <ArrowLeft size={16} />
            </button>
            <div>
              <div className="bp-mono text-[12px] tracking-[0.25em] uppercase" style={{ color: "#8FA0AC" }}>Messaging</div>
              <h1 className="bp-display text-lg sm:text-xl font-semibold uppercase tracking-wide">{CLIENTS[messagingClientId].name}</h1>
            </div>
          </div>
        </header>
        <main className="max-w-3xl mx-auto px-4 sm:px-6 py-5">
          <NotificationPrompt ownerId="coach" />
          <MessageThread clientId={messagingClientId} role="coach" />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full" style={{ backgroundColor: "#12191F", color: "#EDF1F4" }}>
      <header className="sticky top-0 z-20" style={{ backgroundColor: "#12191Fcc", backdropFilter: "blur(6px)", borderBottom: "1px solid #263139" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-2">
          <button onClick={onBack} aria-label="Back" className="p-1 -ml-1 rounded-lg" style={{ color: "#8FA0AC" }}>
            <ArrowLeft size={16} />
          </button>
          <div>
            <div className="bp-mono text-[12px] tracking-[0.25em] uppercase" style={{ color: "#8FA0AC" }}>JYPerformance</div>
            <h1 className="bp-display text-lg sm:text-xl font-semibold uppercase tracking-wide">Coach Dashboard</h1>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-5">
        <NotificationPrompt ownerId="coach" />

        {!isUsingSupabase && (
          <div className="mb-4 rounded-lg px-3 py-2.5 text-[14px]" style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#8FA0AC" }}>
            No Supabase connection — this only shows activity and messages logged from this browser/device, not from clients' phones. Connect Supabase (see README) for a real cross-device view.
          </div>
        )}

        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setShowTeamChannel(true)}
            className="flex-1 flex items-center gap-2.5 rounded-lg px-4 py-3"
            style={{ backgroundColor: "#1B252D", border: "1px solid #263139" }}
          >
            <Megaphone size={16} style={{ color: "#C9A15F" }} />
            <span className="text-[15px] font-medium flex-1 text-left">Team Channel</span>
          </button>
          <button
            onClick={() => setShowAddClient(true)}
            aria-label="Add client"
            className="flex items-center justify-center rounded-lg px-4"
            style={{ backgroundColor: "#1B252D", border: "1px solid #263139", color: "#C9A15F" }}
          >
            <UserPlus size={18} />
          </button>
        </div>

        {allLogs === null ? (
          <div className="text-center py-8 bp-mono text-xs" style={{ color: "#5C6D78" }}>Loading…</div>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-3">
              <div className="flex-1 flex items-center gap-2 rounded-lg px-3 py-2" style={{ backgroundColor: "#1B252D", border: "1px solid #263139" }}>
                <Search size={14} style={{ color: "#5C6D78" }} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search clients…"
                  className="flex-1 bg-transparent outline-none text-[15px]"
                  style={{ color: "#EDF1F4" }}
                />
              </div>
            </div>
            <div className="flex gap-1.5 mb-4">
              {[
                { key: "name", label: "Name" },
                { key: "quiet", label: "Quietest First" },
                { key: "unread", label: "Unread" },
              ].map((opt) => (
                <button
                  key={opt.key}
                  onClick={() => setSortBy(opt.key)}
                  className="bp-mono text-[11.5px] uppercase tracking-widest px-2.5 py-1.5 rounded-lg"
                  style={{ backgroundColor: sortBy === opt.key ? "#C9A15F" : "#1B252D", color: sortBy === opt.key ? "#12191F" : "#8FA0AC", border: `1px solid ${sortBy === opt.key ? "#C9A15F" : "#263139"}` }}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {(() => {
              const query = searchQuery.trim().toLowerCase();
              let visibleIds = query ? ids.filter((id) => CLIENTS[id].name.toLowerCase().includes(query)) : ids;
              const withMeta = visibleIds.map((id) => {
                const summary = computeClientSummary(CLIENTS[id], allLogs[id]);
                const inactiveDays = summary.lastActive ? daysSince(summary.lastActive, todayStr()) : Infinity;
                const unread = (msgSummaries[id] || { unread: 0 }).unread;
                return { id, summary, inactiveDays, unread };
              });
              if (sortBy === "name") withMeta.sort((a, b) => CLIENTS[a.id].name.localeCompare(CLIENTS[b.id].name));
              else if (sortBy === "quiet") withMeta.sort((a, b) => b.inactiveDays - a.inactiveDays);
              else if (sortBy === "unread") withMeta.sort((a, b) => b.unread - a.unread);

              if (withMeta.length === 0) {
                return (
                  <p className="text-[15px] text-center py-6" style={{ color: "#5C6D78" }}>
                    {query ? `No clients matching "${searchQuery}"` : "No clients yet."}
                  </p>
                );
              }

              return (
                <div className="space-y-2">
                  {withMeta.map(({ id, summary }) => {
                    const msgSummary = msgSummaries[id] || { unread: 0, lastMessage: null };
                    const checkin = checkinSummaries[id];
                    const inactiveDays = summary.lastActive ? daysSince(summary.lastActive, todayStr()) : null;
                    const isStale = inactiveDays === null || inactiveDays >= 5;
                    return (
                      <div key={id} className="rounded-lg px-4 py-3" style={{ backgroundColor: "#1B252D", border: `1px solid ${isStale ? "#D9603B55" : "#263139"}` }}>
                        <button onClick={() => onOpenClient(id)} className="w-full text-left">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-[16px] font-medium">{CLIENTS[id].name}</span>
                            <span className="bp-mono text-[13px]" style={{ color: "#C9A15F" }}>{summary.pct}%</span>
                          </div>
                          <div className="h-1.5 w-full rounded-full overflow-hidden mb-2" style={{ backgroundColor: "#263139" }}>
                            <div className="h-full rounded-full" style={{ width: `${summary.pct}%`, backgroundColor: "#C9A15F" }} />
                          </div>
                          <div className="flex items-center justify-between bp-mono text-[12px] mb-1" style={{ color: "#5C6D78" }}>
                            <span>{summary.doneItems}/{summary.totalItems} logged</span>
                            {checkin && (
                              <span className="flex items-center gap-1.5" style={{ color: "#8FA0AC" }}>
                                <Moon size={10} />{checkin.sleep} <Battery size={10} />{checkin.energy}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1 bp-mono text-[12px]" style={{ color: isStale ? "#E0A63B" : "#5C6D78" }}>
                            {isStale && <AlertTriangle size={11} />}
                            <span>
                              {summary.lastActive
                                ? `${isStale ? `Quiet ${inactiveDays}d — last active ` : "Last active "}${formatDate(summary.lastActive)}`
                                : "No activity yet"}
                            </span>
                          </div>
                        </button>
                        <button
                          onClick={() => setMessagingClientId(id)}
                          className="w-full flex items-center justify-between gap-2 mt-3 pt-3 text-left"
                          style={{ borderTop: "1px solid #263139" }}
                        >
                          <span className="flex items-center gap-1.5 min-w-0 text-[14px]" style={{ color: "#AEBEC8" }}>
                            <MessageCircle size={13} style={{ color: "#8FA0AC", flexShrink: 0 }} />
                            <span className="truncate">
                              {msgSummary.lastMessage ? msgSummary.lastMessage.body : "No messages yet"}
                            </span>
                          </span>
                          {msgSummary.unread > 0 && (
                            <span className="flex-shrink-0 bp-mono text-[12px] font-medium rounded-full px-1.5 py-0.5" style={{ backgroundColor: "#D9603B", color: "#EDF1F4" }}>
                              {msgSummary.unread}
                            </span>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </>
        )}
      </main>
    </div>
  );
}

/* ============================================================================
   CLIENT PROGRAM VIEW
============================================================================ */
function ClientProgram({ clientId, clientData, isCoachView = false, onBack, onCoach }) {
  const [activeTab, setActiveTab] = useState("prep"); // domain key, or "history"/"messages"/"team"
  const [activeWeekStart, setActiveWeekStart] = useState(null); // ISO Monday of the selected week
  const [activeDay, setActiveDay] = useState(null); // ISO date of the selected day within that week
  const [logs, setLogs] = useState({});
  const [expanded, setExpanded] = useState({});
  const [loading, setLoading] = useState(true);
  const [showAddHome, setShowAddHome] = useState(true);
  const [playingVideo, setPlayingVideo] = useState(null); // { url, title } | null
  const [programOverrides, setProgramOverrides] = useState({});
  const [editingWeek, setEditingWeek] = useState(null); // { weekStart, initialData } | null — weekStart here is a DAY date, WeekEditor edits one day at a time
  const [checkin, setCheckin] = useState(undefined); // undefined = loading, null = none yet, object = done
  const [showCheckin, setShowCheckin] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    loadLogs(clientId).then((data) => {
      if (!cancelled) {
        setLogs(data);
        setLoading(false);
      }
    });
    return () => { cancelled = true; };
  }, [clientId]);

  const refreshOverrides = useCallback(() => {
    loadProgramOverrides(clientId).then(setProgramOverrides);
  }, [clientId]);

  useEffect(() => {
    refreshOverrides();
  }, [refreshOverrides]);

  // Daily readiness check-in — client-facing only, not shown when a coach
  // is peeking at a client's program from the dashboard.
  useEffect(() => {
    if (isCoachView) return;
    let cancelled = false;
    loadCheckin(clientId, todayStr()).then((data) => {
      if (cancelled) return;
      setCheckin(data);
      setShowCheckin(!data);
    });
    return () => { cancelled = true; };
  }, [clientId, isCoachView]);

  const logExercise = useCallback(
    (id, meta) => {
      const entry = { date: todayStr(), weight: "", ...meta };
      setLogs((prev) => ({ ...prev, [id]: entry }));
      setExpanded((prev) => ({ ...prev, [id]: true }));
      saveLog(clientId, id, entry);
    },
    [clientId]
  );

  const unlogExercise = useCallback(
    (id) => {
      setLogs((prev) => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
      setExpanded((prev) => ({ ...prev, [id]: false }));
      deleteLog(clientId, id);
    },
    [clientId]
  );

  const updateLogField = useCallback(
    (id, field, value) => {
      setLogs((prev) => {
        if (!prev[id]) return prev;
        const nextEntry = { ...prev[id], [field]: value };
        saveLog(clientId, id, nextEntry);
        return { ...prev, [id]: nextEntry };
      });
    },
    [clientId]
  );

  const isHistoryTab = activeTab === "history";
  const isMessagesTab = activeTab === "messages";
  const isTeamTab = activeTab === "team";
  const domainMeta = !isHistoryTab && !isMessagesTab && !isTeamTab ? DOMAIN_META[activeTab] : null;
  const staticDomainProgram = !isHistoryTab && !isMessagesTab && !isTeamTab ? clientData.programs[activeTab] : null;
  const isLiftingTab = activeTab === "lifting";

  // Merge coach-editor overrides on top of the static clients.js content.
  // Both static content and overrides are keyed by individual DAY dates now
  // (not just Mondays) — a `null` override tombstones a static day; an
  // object overrides/adds one.
  const domainProgram = useMemo(() => {
    if (!staticDomainProgram) return null;
    const overridesForDomain = programOverrides[activeTab] || {};
    const mergedDays = { ...staticDomainProgram.weeks };
    Object.entries(overridesForDomain).forEach(([day, val]) => {
      if (val === null) delete mergedDays[day];
      else mergedDays[day] = val;
    });
    return { ...staticDomainProgram, weeks: mergedDays };
  }, [staticDomainProgram, programOverrides, activeTab]);

  const allDayKeys = useMemo(() => (domainProgram ? Object.keys(domainProgram.weeks || {}).sort() : []), [domainProgram]);

  // Which Mondays have at least one programmed day — drives the week strip.
  const weekKeys = useMemo(() => {
    const set = new Set(allDayKeys.map((d) => mondayOf(d)));
    return [...set].sort();
  }, [allDayKeys]);

  // Whenever the domain changes, land on the most sensible week for it:
  // the one containing today, else the nearest upcoming one, else the
  // most recent one written so far.
  useEffect(() => {
    if (weekKeys.length === 0) { setActiveWeekStart(null); setActiveDay(null); return; }
    if (!activeWeekStart || !weekKeys.includes(activeWeekStart)) {
      const nextWeekStart = pickDefaultWeek(weekKeys, todayStr());
      setActiveWeekStart(nextWeekStart);
      const today = todayStr();
      setActiveDay(isCurrentWeek(nextWeekStart, today) ? today : nextWeekStart);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, weekKeys]);

  const weekDays = useMemo(() => (activeWeekStart ? daysOfWeek(activeWeekStart) : []), [activeWeekStart]);

  const dayData = domainProgram?.weeks?.[activeDay];
  const accent = domainMeta?.accent || "#C9A15F";

  const dayItemIds = useMemo(() => {
    const ids = [];
    if (dayData) dayData.blocks.forEach((block, bi) => block.items.forEach((_, ii) => ids.push(`${activeTab}-${activeDay}-${bi}-${ii}`)));
    return ids;
  }, [dayData, activeTab, activeDay]);

  const doneCount = dayItemIds.filter((id) => logs[id]).length;
  const pct = dayItemIds.length ? Math.round((doneCount / dayItemIds.length) * 100) : 0;
  const dayComplete = dayItemIds.length > 0 && doneCount === dayItemIds.length;

  // Status per day within the active week — drives the day-strip dots.
  const dayStatus = useMemo(() => {
    const status = {};
    if (!domainProgram) return status;
    weekDays.forEach((day) => {
      const dd = domainProgram.weeks[day];
      if (!dd) { status[day] = "none"; return; }
      const ids = [];
      dd.blocks.forEach((block, bi) => block.items.forEach((_, ii) => ids.push(`${activeTab}-${day}-${bi}-${ii}`)));
      const done = ids.filter((id) => logs[id]).length;
      status[day] = ids.length === 0 ? "none" : done === 0 ? "empty" : done === ids.length ? "full" : "partial";
    });
    return status;
  }, [domainProgram, weekDays, activeTab, logs]);

  // Last dated day on file for this domain, so the header can nudge
  // "add more soon" once the client is about to run out of programming.
  const programmedThrough = allDayKeys.length ? allDayKeys[allDayKeys.length - 1] : null;
  const daysOfProgrammingLeft = programmedThrough
    ? Math.round((new Date(programmedThrough + "T00:00:00") - new Date(todayStr() + "T00:00:00")) / 86400000)
    : null;

  const saveFocusOnly = useCallback(
    async (newFocus) => {
      if (!activeDay) return;
      await saveProgramWeek(clientId, activeTab, activeDay, { focus: newFocus, blocks: dayData?.blocks || [] });
      refreshOverrides();
    },
    [clientId, activeTab, activeDay, dayData, refreshOverrides]
  );

  const historyEntries = useMemo(() => Object.entries(logs).map(([id, entry]) => ({ id, ...entry })).sort((a, b) => (a.date < b.date ? 1 : -1)), [logs]);

  return (
    <div className="min-h-screen w-full" style={{ backgroundColor: "#12191F", color: "#EDF1F4" }}>
      <header className="sticky top-0 z-20" style={{ backgroundColor: "#12191Fcc", backdropFilter: "blur(6px)", borderBottom: "1px solid #263139" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <button onClick={onBack} aria-label="Back to client select" className="flex-shrink-0 p-1 -ml-1 rounded-lg" style={{ color: "#8FA0AC" }}>
              <ArrowLeft size={16} />
            </button>
            <div className="min-w-0">
              <div className="bp-mono text-[12px] tracking-[0.25em] uppercase" style={{ color: "#8FA0AC" }}>JYPerformance</div>
              <h1 className="bp-display text-lg sm:text-xl font-semibold uppercase tracking-wide truncate">{clientData.name}</h1>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {!isUsingSupabase && (
              <span className="bp-mono text-[10.5px] uppercase tracking-wide px-2 py-1 rounded-lg hidden sm:inline" style={{ color: "#8FA0AC", border: "1px solid #263139" }} title="Progress is saved on this device only.">
                Local only
              </span>
            )}
            <button onClick={onCoach} className="flex items-center gap-1.5 bp-mono text-[11px] uppercase tracking-wide px-2.5 py-1.5 rounded-lg" style={{ color: "#8FA0AC", border: "1px solid #263139" }}>
              <Users size={12} /> Coach
            </button>
          </div>
        </div>
      </header>

      {showAddHome && (
        <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-3">
          <div className="flex items-start gap-2.5 rounded-lg px-3 py-2.5" style={{ backgroundColor: "#1B252D", border: "1px solid #263139" }}>
            <Smartphone size={15} className="flex-shrink-0 mt-0.5" style={{ color: "#C9A15F" }} />
            <div className="flex-1 text-[14px] leading-snug" style={{ color: "#AEBEC8" }}>
              Add this to your home screen for one-tap access: iPhone — tap <Share size={11} className="inline mx-0.5 mb-0.5" /> then "Add to Home Screen." Android — menu → "Install app."
            </div>
            <button onClick={() => setShowAddHome(false)} aria-label="Dismiss" className="flex-shrink-0" style={{ color: "#5C6D78" }}>
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      {/* Tabs */}
      <nav className="max-w-3xl mx-auto px-4 sm:px-6 pt-4">
        <div className="grid grid-cols-5 gap-1">
          {DOMAIN_KEYS.map((key) => {
            const meta = DOMAIN_META[key];
            const Icon = meta.icon;
            const isActive = key === activeTab;
            return (
              <button key={key} onClick={() => setActiveTab(key)} className="flex flex-col items-center justify-center gap-1.5 py-2.5 px-0.5" style={{ borderBottom: `2px solid ${isActive ? meta.accent : "transparent"}`, color: isActive ? "#EDF1F4" : "#5C6D78" }}>
                <Icon size={16} strokeWidth={isActive ? 2.25 : 1.75} color={isActive ? meta.accent : "#5C6D78"} />
                <span className="bp-mono text-[10px] uppercase tracking-tight text-center leading-tight whitespace-nowrap">{meta.tabLabel}</span>
              </button>
            );
          })}
        </div>
        <div className="grid grid-cols-3 gap-1 mt-0.5" style={{ borderTop: "1px solid #1E2A32" }}>
          <button onClick={() => setActiveTab("history")} className="flex flex-col items-center justify-center gap-1.5 py-2.5 px-0.5" style={{ borderBottom: `2px solid ${isHistoryTab ? "#C9A15F" : "transparent"}`, color: isHistoryTab ? "#EDF1F4" : "#5C6D78" }}>
            <HistoryIcon size={16} strokeWidth={isHistoryTab ? 2.25 : 1.75} color={isHistoryTab ? "#C9A15F" : "#5C6D78"} />
            <span className="bp-mono text-[10px] uppercase tracking-tight text-center leading-tight whitespace-nowrap">History</span>
          </button>
          <button onClick={() => setActiveTab("messages")} className="flex flex-col items-center justify-center gap-1.5 py-2.5 px-0.5" style={{ borderBottom: `2px solid ${isMessagesTab ? "#C9A15F" : "transparent"}`, color: isMessagesTab ? "#EDF1F4" : "#5C6D78" }}>
            <MessageCircle size={16} strokeWidth={isMessagesTab ? 2.25 : 1.75} color={isMessagesTab ? "#C9A15F" : "#5C6D78"} />
            <span className="bp-mono text-[10px] uppercase tracking-tight text-center leading-tight whitespace-nowrap">Messages</span>
          </button>
          <button onClick={() => setActiveTab("team")} className="flex flex-col items-center justify-center gap-1.5 py-2.5 px-0.5" style={{ borderBottom: `2px solid ${isTeamTab ? "#C9A15F" : "transparent"}`, color: isTeamTab ? "#EDF1F4" : "#5C6D78" }}>
            <Megaphone size={16} strokeWidth={isTeamTab ? 2.25 : 1.75} color={isTeamTab ? "#C9A15F" : "#5C6D78"} />
            <span className="bp-mono text-[10px] uppercase tracking-tight text-center leading-tight whitespace-nowrap">Team</span>
          </button>
        </div>
      </nav>

      {!isHistoryTab && !isMessagesTab && !isTeamTab && (weekKeys.length > 0 || isCoachView) && (
        <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-4">
          <div className="flex items-center justify-between mb-2 px-0.5">
            <span className="bp-mono text-[12px] uppercase tracking-widest" style={{ color: "#8FA0AC" }}>
              {activeWeekStart ? formatWeekRange(activeWeekStart) : "Week"}
            </span>
            <span className="bp-mono text-[12px]" style={{ color: "#8FA0AC" }}>{doneCount}/{dayItemIds.length || 0} logged</span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto pb-1 mb-2" style={{ scrollbarWidth: "none" }}>
            {weekKeys.map((wk) => {
              const isActive = wk === activeWeekStart;
              const isThisWeek = isCurrentWeek(wk, todayStr());
              return (
                <button
                  key={wk}
                  onClick={() => {
                    setActiveWeekStart(wk);
                    const today = todayStr();
                    setActiveDay(isCurrentWeek(wk, today) ? today : wk);
                  }}
                  className="flex-shrink-0 flex flex-col items-center justify-center gap-1 rounded-lg px-2.5"
                  style={{ minWidth: 58, height: 42, backgroundColor: isActive ? accent : "#1B252D", border: `1px solid ${isActive ? accent : isThisWeek ? accent + "70" : "#263139"}` }}
                >
                  <span className="bp-mono text-[12.5px] font-medium whitespace-nowrap" style={{ color: isActive ? "#12191F" : "#8FA0AC" }}>{formatWeekChip(wk)}</span>
                  {isThisWeek && (
                    <span className="bp-mono text-[9px] uppercase tracking-widest whitespace-nowrap" style={{ color: isActive ? "#12191F99" : accent }}>This week</span>
                  )}
                </button>
              );
            })}
            {isCoachView && (
              <button
                onClick={() => {
                  const nextStart = weekKeys.length ? addDays(weekKeys[weekKeys.length - 1], 7) : mondayOf(todayStr());
                  setActiveWeekStart(nextStart);
                  setActiveDay(nextStart);
                }}
                aria-label="Add next week"
                className="flex-shrink-0 flex flex-col items-center justify-center gap-1 rounded-lg px-2.5"
                style={{ minWidth: 42, height: 42, border: "1px dashed #263139", color: "#8FA0AC" }}
              >
                <Plus size={16} />
              </button>
            )}
          </div>

          {activeWeekStart && (
            <div className="flex gap-1.5 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
              {weekDays.map((day) => {
                const isActive = day === activeDay;
                const isToday = day === todayStr();
                const status = dayStatus[day];
                return (
                  <button
                    key={day}
                    onClick={() => setActiveDay(day)}
                    className="flex-shrink-0 flex flex-col items-center justify-center gap-1 rounded-lg px-2"
                    style={{ minWidth: 50, height: 46, backgroundColor: isActive ? accent : "#1B252D", border: `1px solid ${isActive ? accent : isToday ? accent + "70" : "#263139"}` }}
                  >
                    <span className="bp-mono text-[11px] font-medium whitespace-nowrap" style={{ color: isActive ? "#12191F" : "#8FA0AC" }}>{formatDayChip(day)}</span>
                    {status === "full" ? (
                      <Check size={11} strokeWidth={3} color={isActive ? "#12191F" : accent} />
                    ) : (
                      <span className="rounded-full" style={{ width: 5, height: 5, backgroundColor: "transparent", border: status === "partial" ? `1px solid ${isActive ? "#12191F" : accent}` : status === "empty" ? `1px solid ${isActive ? "#12191F55" : "#3A4750"}` : "1px solid transparent" }} />
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {editingWeek && (
        <WeekEditor
          clientId={clientId}
          domain={activeTab}
          domainLabel={domainMeta?.label || activeTab}
          accent={accent}
          weekStart={editingWeek.weekStart}
          initialData={editingWeek.initialData}
          onClose={() => setEditingWeek(null)}
          onSaved={() => { setEditingWeek(null); refreshOverrides(); }}
          onDeleted={() => { setEditingWeek(null); refreshOverrides(); }}
        />
      )}

      {showCheckin && !isCoachView && (
        <ReadinessCheckin
          clientId={clientId}
          onDone={() => { setShowCheckin(false); loadCheckin(clientId, todayStr()).then(setCheckin); }}
          onSkip={() => setShowCheckin(false)}
        />
      )}

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-5">
        {isMessagesTab ? (
          <>
            <NotificationPrompt ownerId={clientId} />
            <MessageThread clientId={clientId} role="client" />
          </>
        ) : isTeamTab ? (
          <>
            <NotificationPrompt ownerId={clientId} />
            <TeamChannel selfId={isCoachView ? "coach" : clientId} selfName={isCoachView ? "Coach" : clientData.name} readOnly={!isCoachView} />
          </>
        ) : isHistoryTab ? (
          <HistoryFeed entries={historyEntries} onPlayVideo={(url, title) => setPlayingVideo({ url, title })} />
        ) : (
          <>
            <div className="rounded-lg p-4 mb-4" style={{ backgroundColor: "#1B252D", borderLeft: `3px solid ${accent}` }}>
              <div className="flex items-start justify-between gap-2 mb-1">
                <h2 className="bp-display text-base sm:text-lg uppercase tracking-wide">{domainMeta.label}</h2>
                {isCoachView && activeDay && (
                  <button
                    onClick={() => setEditingWeek({ weekStart: activeDay, initialData: dayData || null })}
                    className="flex-shrink-0 flex items-center gap-1 bp-mono text-[11px] uppercase tracking-widest px-2 py-1 rounded-lg"
                    style={{ border: `1px solid ${accent}55`, color: accent }}
                  >
                    <Pencil size={11} /> Edit
                  </button>
                )}
              </div>

              {/* Focus — coach can edit inline right here; clients just see it */}
              {isCoachView ? (
                <input
                  type="text"
                  defaultValue={dayData?.focus || ""}
                  key={activeDay}
                  onBlur={(e) => { if (e.target.value !== (dayData?.focus || "")) saveFocusOnly(e.target.value); }}
                  placeholder="Add a focus note for this day…"
                  className="w-full text-[15px] bg-transparent outline-none border-b border-dashed pb-1"
                  style={{ color: "#EDF1F4", borderColor: "#3A4750" }}
                />
              ) : (
                dayData?.focus && <p className="text-[15px] leading-relaxed" style={{ color: "#AEBEC8" }}>{dayData.focus}</p>
              )}

              {programmedThrough && (
                <p className="bp-mono text-[12px] mt-2" style={{ color: daysOfProgrammingLeft <= 10 ? "#E0A63B" : "#5C6D78" }}>
                  Programmed through {formatDate(programmedThrough)}
                  {daysOfProgrammingLeft <= 10 ? " — add more soon" : ""}
                </p>
              )}
              {dayItemIds.length > 0 && (
                <div className="mt-3 h-1 w-full rounded-full overflow-hidden" style={{ backgroundColor: "#263139" }}>
                  <div className="h-full transition-all duration-300 rounded-full" style={{ width: `${pct}%`, backgroundColor: accent }} />
                </div>
              )}
            </div>

            {loading && <div className="text-center py-8 bp-mono text-xs" style={{ color: "#5C6D78" }}>Loading…</div>}

            {!loading && !dayData && (
              <div className="rounded-lg p-6 text-center" style={{ border: "1px solid #263139" }}>
                <p className="bp-mono text-xs uppercase tracking-widest mb-1" style={{ color: "#5C6D78" }}>Programming In Progress</p>
                <p className="text-sm mb-3" style={{ color: "#8FA0AC" }}>
                  {activeDay
                    ? `${formatDayLabel(activeDay)} hasn't been drafted yet for ${clientData.name}.`
                    : `No ${domainMeta.label.toLowerCase()} programming has been added for ${clientData.name} yet.`}
                </p>
                {isCoachView && (
                  <button
                    onClick={() => setEditingWeek({ weekStart: activeDay || mondayOf(todayStr()), initialData: null })}
                    className="inline-flex items-center gap-1.5 bp-mono text-[12px] uppercase tracking-widest px-3 py-1.5 rounded-lg"
                    style={{ backgroundColor: accent, color: "#12191F" }}
                  >
                    <Plus size={12} /> Write This Day
                  </button>
                )}
              </div>
            )}

            {!loading && dayData && dayComplete && (
              <div className="rounded-lg p-6 text-center" style={{ border: `1px solid ${accent}55`, backgroundColor: "#161F26" }}>
                <div className="w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3" style={{ backgroundColor: accent }}>
                  <Check size={18} strokeWidth={3} color="#12191F" />
                </div>
                <p className="bp-mono text-xs uppercase tracking-widest mb-1" style={{ color: accent }}>Day Complete</p>
                <p className="text-sm mb-3" style={{ color: "#8FA0AC" }}>Every drill for {formatDayLabel(activeDay)} is checked off.</p>
                <button
                  onClick={() => setActiveTab("history")}
                  className="inline-flex items-center gap-1.5 bp-mono text-[12px] uppercase tracking-widest px-3 py-1.5 rounded-lg"
                  style={{ border: `1px solid ${accent}55`, color: accent }}
                >
                  <HistoryIcon size={12} /> View in History
                </button>
              </div>
            )}

            {!loading && dayData && !dayComplete && (
              <div className="space-y-4">
                {dayData.blocks.map((block, bi) => (
                  <section key={bi} className="rounded-lg overflow-hidden" style={{ backgroundColor: "#161F26", border: "1px solid #22303A" }}>
                    <div className="bp-mono text-[12px] uppercase tracking-widest px-4 py-2" style={{ color: accent, backgroundColor: "#1B252D", borderBottom: "1px solid #22303A" }}>{block.title}</div>
                    <ul>
                      {block.items.map((item, ii) => {
                        const id = `${activeTab}-${activeDay}-${bi}-${ii}`;
                        const entry = logs[id];
                        const isDone = !!entry;
                        const isExpanded = !!expanded[id];
                        return (
                          <li key={id} style={{ borderBottom: "1px solid #1E2A32" }}>
                            <div className="flex items-start gap-3 px-4 py-3">
                              <button
                                onClick={() => (isDone ? unlogExercise(id) : logExercise(id, { name: item.name, detail: item.detail, domain: activeTab, week: activeDay, video: item.video || "" }))}
                                aria-label={isDone ? `Remove log for ${item.name}` : `Log ${item.name} complete`}
                                className="mt-0.5 flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center"
                                style={{ backgroundColor: isDone ? accent : "transparent", border: `1.5px solid ${isDone ? accent : "#3A4750"}` }}
                              >
                                {isDone && <Check size={12} strokeWidth={3} color="#12191F" />}
                              </button>
                              <div className="min-w-0 flex-1">
                                <div className="flex items-start justify-between gap-2">
                                  <div style={{ opacity: isDone ? 0.75 : 1 }}>
                                    <div className="text-[15.5px] font-medium" style={{ color: "#EDF1F4" }}>{item.name}</div>
                                    <div className="bp-mono text-[13px] mt-0.5" style={{ color: accent }}>{item.detail}</div>
                                    {item.cue && <div className="text-[14px] mt-1 leading-snug" style={{ color: "#8FA0AC" }}>{item.cue}</div>}
                                    {item.video && (
                                      <button
                                        onClick={() => setPlayingVideo({ url: item.video, title: item.name })}
                                        className="inline-flex items-center gap-1 text-[13px] mt-1.5 px-2 py-1 rounded-lg"
                                        style={{ color: accent, border: `1px solid ${accent}55` }}
                                      >
                                        <Video size={11} /> Watch demo
                                      </button>
                                    )}
                                  </div>
                                  {isDone && isLiftingTab && (
                                    <button onClick={() => setExpanded((prev) => ({ ...prev, [id]: !prev[id] }))} aria-label={isExpanded ? "Collapse log details" : "Add weight logged"} className="flex-shrink-0 mt-0.5 p-1 rounded-lg" style={{ color: "#8FA0AC" }}>
                                      <ChevronDown size={15} style={{ transform: isExpanded ? "rotate(180deg)" : "none", transition: "transform 0.15s" }} />
                                    </button>
                                  )}
                                </div>

                                {isDone && isLiftingTab && isExpanded && (
                                  <div className="mt-3 pt-3 space-y-2" style={{ borderTop: "1px dashed #263139" }}>
                                    <div className="bp-mono text-[12px] uppercase tracking-widest" style={{ color: "#5C6D78" }}>Logged {formatDate(entry.date)}</div>
                                    <div>
                                      <label className="bp-mono text-[11px] uppercase tracking-widest block mb-1" style={{ color: "#8FA0AC" }}>Weight / Load</label>
                                      <input
                                        type="text"
                                        value={entry.weight}
                                        onChange={(e) => updateLogField(id, "weight", e.target.value)}
                                        placeholder="e.g. 225 lb, or bodyweight"
                                        className="w-full text-[15px] rounded-lg px-2.5 py-1.5"
                                        style={{ backgroundColor: "#12191F", border: "1px solid #263139", color: "#EDF1F4" }}
                                      />
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </section>
                ))}
              </div>
            )}
          </>
        )}
      </main>

      <footer className="max-w-3xl mx-auto px-4 sm:px-6 pb-8 pt-2">
        <div className="bp-mono text-[11px] uppercase tracking-widest text-center" style={{ color: "#3A4750" }}>
          JYPerformance — Ongoing Training Program — Arm Care Runs Every Day
        </div>
      </footer>

      {playingVideo && (
        <VideoModal url={playingVideo.url} title={playingVideo.title} onClose={() => setPlayingVideo(null)} />
      )}
    </div>
  );
}

function HistoryFeed({ entries, onPlayVideo }) {
  if (entries.length === 0) {
    return (
      <div className="rounded-lg p-6 text-center" style={{ border: "1px solid #263139" }}>
        <p className="bp-mono text-xs uppercase tracking-widest mb-1" style={{ color: "#5C6D78" }}>No History Yet</p>
        <p className="text-sm" style={{ color: "#8FA0AC" }}>Logged sessions from every tab will build up here over time.</p>
      </div>
    );
  }

  const grouped = [];
  let lastDate = null;
  entries.forEach((entry) => {
    if (entry.date !== lastDate) {
      grouped.push({ date: entry.date, items: [entry] });
      lastDate = entry.date;
    } else {
      grouped[grouped.length - 1].items.push(entry);
    }
  });

  return (
    <div className="space-y-5">
      <div className="rounded-lg p-4" style={{ backgroundColor: "#1B252D", borderLeft: "3px solid #C9A15F" }}>
        <h2 className="bp-display text-base sm:text-lg uppercase tracking-wide mb-1.5">Full History</h2>
        <p className="text-[15px] leading-relaxed" style={{ color: "#AEBEC8" }}>Every session logged across every tab, most recent first. {entries.length} total entries.</p>
      </div>

      {grouped.map((group) => (
        <div key={group.date}>
          <div className="bp-mono text-[12px] uppercase tracking-widest mb-2 px-1" style={{ color: "#8FA0AC" }}>{formatDate(group.date)}</div>
          <div className="rounded-lg overflow-hidden" style={{ backgroundColor: "#161F26", border: "1px solid #22303A" }}>
            {group.items.map((entry, i) => {
              const meta = DOMAIN_META[entry.domain];
              const Icon = meta?.icon || Check;
              return (
                <div key={entry.id} className="flex items-start gap-3 px-4 py-3" style={{ borderBottom: i === group.items.length - 1 ? "none" : "1px solid #1E2A32" }}>
                  <div className="mt-0.5 flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center" style={{ backgroundColor: (meta?.accent || "#C9A15F") + "22" }}>
                    <Icon size={13} color={meta?.accent || "#C9A15F"} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-[15.5px] font-medium" style={{ color: "#EDF1F4" }}>{entry.name}</div>
                      <span className="bp-mono text-[11px] uppercase tracking-wide flex-shrink-0" style={{ color: meta?.accent }}>{formatWeekChip(entry.week)} · {meta?.tabLabel}</span>
                    </div>
                    <div className="bp-mono text-[13px] mt-0.5" style={{ color: "#8FA0AC" }}>{entry.detail}</div>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1.5">
                      {entry.weight && (
                        <span className="text-[14px]" style={{ color: "#AEBEC8" }}>
                          <span className="bp-mono" style={{ color: "#5C6D78" }}>Load: </span>{entry.weight}
                        </span>
                      )}
                      {entry.video && (
                        <button
                          onClick={() => onPlayVideo(entry.video, entry.name)}
                          className="inline-flex items-center gap-1 text-[14px]"
                          style={{ color: meta?.accent }}
                        >
                          <Video size={11} /> Video
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
