# JYPerformance — Client Training App

Multi-client app for an ongoing coaching relationship — PIN gate per
client, a coach dashboard, full history logging (weight + demo videos),
in-app messaging, a team announcement channel, and "Add to Home Screen"
support. Programming is date-based and rolling (not a fixed N-week cycle),
so it's built for clients you train long-term.

## How it works

- `src/clients.js` — one entry per client: name, 4-digit PIN, and their
  program content. This is the file you edit for every new athlete (or use
  the in-app **+ Add Client** flow instead — see below).
- `src/App.jsx` — the app shell (routing, login, coach dashboard, program
  view). You shouldn't need to touch this to add a client.
- Clients log in on the app's home screen with their **name + PIN** (like a
  username/password) — no directory of names is ever shown to them, so
  they can't see who else is a client. A client's own bookmarkable link is
  `yoursite.com/?client=their-key`, which skips straight to the PIN prompt.
- Coach access is `yoursite.com/?coach=1`, gated by a separate PIN
  (`VITE_COACH_PIN`, default `0000` if unset — **change this before sending
  links to real clients**). Coach login is PIN-only, no name.

## Adding your clients

1. Open `src/clients.js`.
2. Copy the `"lindsey"` block (all 5 domains) to a new entry.
3. Change the key (becomes their URL), `name`, and `pin` (must be unique —
   this is what stops clients from opening each other's link and seeing
   each other's logs; it's a light gate, not real security).
4. Fill in their programming, keyed by day (see "Weeks are dates, days are
   real" below). Days you haven't written yet show a clean "programming in
   progress" placeholder instead of breaking.
5. Optionally add a `video` link to any drill — renders as a "Watch demo"
   button under that drill, visible before the client checks it off. Tapping
   it plays the clip in an on-page modal (native `<video>` player) — the
   client never leaves the app or gets sent to another site.
6. Tell each client their name (exactly as typed in `name`) and PIN — that's
   all they need to log in.

You can also add a client from inside the app now (Coach Dashboard →
**+ Add Client**) — see "Adding clients from inside the app" below.

## Weeks are dates, days are real

This is an ongoing program, not a fixed N-week cycle — there's no "week 12"
to build toward, just a rolling few weeks of programming kept ahead of
where the client actually is. Each domain's `weeks` object is keyed by the
ISO date (`YYYY-MM-DD`) of the **specific day** that entry is for — e.g.
`"2026-08-11"` for Tuesday, Aug 11 — not just Mondays. Every day of the
week can have its own drills.

In the app, this shows as two levels: a **week strip** (grouped from
whatever day-dates exist, via each day's Monday) and, once a week is
selected, a **day strip** underneath it showing all 7 days Mon–Sun. Days
you haven't written yet still show up as empty slots — tap one (as coach)
and **Write This Day** to fill it in. Once every drill in a day is checked
off, that day's view collapses to a "Day Complete" card with a link into
History, instead of showing the full checklist again.

You don't need to plan far ahead — in practice, keep about **4 weeks**
filled in at any time (this week plus the next ~3), and add more as time
passes. The app:

- Labels the week containing today **"This week"** in the week strip, and
  picks the current day automatically when a client opens the app.
- Displays **"Programmed through {date}"** under each domain's header, in
  amber once fewer than 10 days of programming remain, so you can see at a
  glance which clients need their next few days written.

To add the next week for a client: use the in-app **+** button at the end
of the week strip (jumps to the next Monday), or add day entries directly
in `clients.js`. Old (past) days can stay in the file indefinitely — they
just won't be the default selection anymore, and the client's checked-off
history is independent of them anyway (see History tab, below).

## What clients can do

- Check off drills, day by day — each one becomes a dated log entry, not
  just a checkbox (nothing gets silently overwritten).
- For **Lifting** specifically, expand a logged drill to record weight/load
  — other domains (Prep, Throwing, Conditioning, Arm Care) skip this since
  it doesn't apply there.
- Watch a demo video attached to any drill, any time — plays right on the
  page, no redirect.
- Open the **History** tab for a full chronological feed of everything
  they've logged, across every domain and day.
- Message you directly from the **Messages** tab — an in-app chat thread,
  so neither of you needs to text from a personal number. They can also
  attach a throwing video right in the chat (see "Video uploads in chat").
- Read the **Team** channel for announcements or general news from you —
  it's read-only for clients, so it stays quiet as your roster grows.
- Add the app to their home screen for one-tap access (banner shown on
  first visit, dismissible).

## Coach dashboard

`yoursite.com/?coach=1` → PIN → a list of every client with a completion
bar, logged/total count, and last-active date. Tap a client's name to open
their program directly — no PIN needed from that side. Tap the message row
under any client to open your chat thread with them and reply — a red
badge shows how many of their messages you haven't read yet.

**Local-only limitation:** without Supabase connected, the coach dashboard
can only see activity and messages logged on the same browser/device it's
viewed from.
Connect Supabase (below) for a dashboard that reflects clients' actual
phones.

## Local development

```
npm install
npm run dev
```

Runs without any setup at `http://localhost:5173`. Logs save to
`localStorage` per client until you connect Supabase, so it's fully
testable with zero external accounts.

## Persistence: local-only vs. synced

Out of the box, each client's logs save to their own browser's
`localStorage`. Works, but doesn't follow them across devices and the coach
dashboard can't see it from your end.

To sync to the cloud instead:

1. Create a free project at [supabase.com](https://supabase.com).
2. In the SQL editor, run everything in `supabase-schema.sql`.
3. In Project Settings → API, copy your Project URL and `anon public` key.
4. Copy `.env.example` to `.env`, fill in `VITE_SUPABASE_URL`,
   `VITE_SUPABASE_ANON_KEY`, and set `VITE_COACH_PIN` to something real.
5. Restart `npm run dev` (or redeploy). The "Local only" badge in the client
   header disappears once Supabase is connected.

## Demo videos (self-recorded)

The `video` field on any drill needs a direct link to a video **file**
(.mp4, .mov, .webm) — not a page link. It plays in an on-page player, so
the URL has to point straight at the file, not a viewer/embed page like a
YouTube watch link.

For clips you record yourself, easiest options:

- **Supabase Storage** (if you're already using Supabase for logs): create
  a public bucket, upload the clip, and use the public URL it gives you —
  e.g. `https://your-project.supabase.co/storage/v1/object/public/demos/rockers.mp4`.
- **Any static host / CDN** (Cloudflare R2, Backblaze B2, S3, etc.) — same
  idea, just needs public read access and a direct file URL.

Keep clips short and compressed (a few MB, not hundreds) — they're loading
on a client's phone, often on cellular data.

## Team Channel

`Team` tab (clients) / `Team Channel` button (coach dashboard) — one shared
thread everyone can read and post in, for announcements, schedule changes,
or general news. Unlike 1:1 messaging, every post shows who sent it.
Same local-only-without-Supabase behavior as everything else.

## Push Notifications

Lets you and your clients get a real phone notification when a message
comes in — the app doesn't need to be open. This needs three things wired
together: a **key pair** (proves the pushes are from you), a place for
each device to **register** it wants pushes (the `push_subscriptions`
table, already in `supabase-schema.sql`), and a **sender** that actually
fires the push when a new message lands (a Supabase Edge Function, since a
browser can't push to *other* devices — only a server can).

1. **Generate a VAPID key pair.** From this project folder:
   ```
   npx web-push generate-vapid-keys
   ```
   This prints a public and private key. Put the public one in `.env` as
   `VITE_VAPID_PUBLIC_KEY`. Keep the private one for step 3 — never put it
   in `.env` or commit it anywhere.

2. **Run the updated `supabase-schema.sql`** in your Supabase SQL editor if
   you haven't already (adds `push_subscriptions` and `team_messages`).

3. **Deploy the Edge Function** that sends the actual pushes
   (`supabase/functions/send-push`). With the [Supabase CLI](https://supabase.com/docs/guides/cli):
   ```
   supabase functions deploy send-push
   supabase secrets set VAPID_PUBLIC_KEY=<the public key from step 1>
   supabase secrets set VAPID_PRIVATE_KEY=<the private key from step 1>
   supabase secrets set VAPID_SUBJECT=mailto:you@example.com
   ```

4. **Wire up the trigger.** In the Supabase dashboard: **Database → Webhooks
   → Create a new hook**, twice:
   - Table `messages`, event `Insert`, target: your `send-push` function
   - Table `team_messages`, event `Insert`, target: the same function

5. **Redeploy the app** (with `VITE_VAPID_PUBLIC_KEY` set as an environment
   variable on Vercel/Netlify too). Clients and you will now see an
   "Enable notifications" prompt on the Messages/Team tabs — tapping it
   asks for browser permission and registers the device.

**Notes:**
- Without `VITE_VAPID_PUBLIC_KEY` set, the notification prompt just doesn't
  appear — nothing breaks, push is simply off.
- **iPhone clients must "Add to Home Screen" first** (see below) — Safari
  only allows push notifications for installed PWAs, and needs iOS 16.4+.
  Android works in the regular browser tab too.
- The push payload uses the client's key (not their name) for the
  notification title on the coach's side, since names live in `clients.js`
  rather than the database. Good enough to know who messaged, not as
  polished as it could be — fine for 6 clients.

## Adding clients from inside the app

For occasional additions, you don't need to touch `clients.js` anymore —
tap **+ Add Client** on the coach dashboard, enter a name and a 4-digit PIN,
and they're added immediately. This only *persists* with Supabase connected
(local-only mode saves to that browser only, same caveat as everything
else). A client added this way starts with default blurbs and no weeks
programmed — open their program and use the week editor to write their
first one.

`clients.js` still works exactly as before for your original roster, and
is a fine place to keep clients you're setting up carefully by hand — the
two approaches coexist.

## Coach dashboard search & sort

Once you're past a handful of clients, use the search box to jump to a
name, and the sort pills to reorder the list: **Name** (alphabetical),
**Quietest First** (surfaces anyone going quiet at the top), or **Unread**
(anyone waiting on a reply from you first).

## Team channel is announcement-only

Clients can read the Team channel but can't post in it — it's from you to
everyone, not an open group chat. Keeps it usable once you're coordinating
more than a handful of people. You (the coach) can still post from the
Team Channel button on your dashboard, or from a client's Team tab if
you're viewing their program directly.

## Editing programming in-app

You no longer have to hand-edit `clients.js` for every new day. Open a
client from the coach dashboard (no PIN needed from there), pick a domain,
and pick a day from the day strip. You'll see:

- An **editable focus line** right under the domain title — type directly
  into it, it saves when you tap away. This replaced the old static
  description text; it's meant for a short day-specific note, not a
  paragraph.
- An **Edit** button for the full drill list — set blocks and drills (name,
  sets/reps, cue, optional demo video URL), same fields as `clients.js`.
- A **+** at the end of the week strip to add the next week (jumps to the
  next Monday); every day within a week is always selectable, whether or
  not it's been written yet.

This only *persists* if Supabase is connected — without it, edits save to
that browser's local storage only, useful for trying the editor out but not
for real use across devices. Once Supabase is connected, in-app edits are
layered on top of `clients.js`: anything you edit or add in-app overrides
the static file, and deleting a day in-app removes it even if `clients.js`
still has an entry there. `clients.js` becomes your seed/demo content —
the day-to-day editing happens in the app from then on.

## Video uploads in chat

Athletes can attach a throwing clip directly in **Messages** or the **Team**
channel — tap the paperclip icon, pick a video, it uploads and shows inline
in the chat bubble (tap to play). This needs a Supabase Storage bucket:

1. Supabase dashboard → **Storage** → **Create a new bucket**.
   - Name: `chat-videos`
   - Public bucket: **ON** (lets an uploaded clip's link be viewed directly
     in a chat bubble without a separate auth step — same permissive model
     as the rest of this app; the bucket itself isn't browsable, only
     specific known video links work).
2. Run the two `storage.objects` policy statements at the bottom of
   `supabase-schema.sql` in the SQL editor (these aren't included in the
   bucket creation step above).

Without this set up, the paperclip button is disabled and shows a tooltip
explaining why — nothing breaks, video attachments are just unavailable
until the bucket exists.

## Daily readiness check-in

The first time a client opens the app each day, they get a quick prompt —
rate sleep, soreness, and energy from 1–5 before their program loads. Takes
five seconds, and today's numbers show up next to their name on your coach
dashboard so you can catch a client running down before they say anything.
They can skip it for the day if they want; it won't nag them again until
tomorrow. Not shown when you (the coach) open a client's program to peek or
edit — this is a client-only prompt.

## Client activity flags

Any client who hasn't logged anything in 5+ days (or has never logged
anything) gets a highlighted row and a "Quiet Xd" flag on your dashboard,
instead of just fading into the list. The goal is to catch a client going
quiet before it turns into a client who's gone.

## Add to Home Screen

`public/manifest.json`, `public/sw.js`, and the icons in `public/` are what
make "Add to Home Screen" produce a real app icon instead of a bookmark
(mainly matters on Android — iOS Safari supports this natively regardless).
The icons shipped here are placeholders (navy square, "BP" monogram) —
swap `icon-192.png`, `icon-512.png`, and `apple-touch-icon.png` for real
artwork whenever you have it; same filenames, same folder.

## Deploying

Easiest path is [Vercel](https://vercel.com) or [Netlify](https://netlify.com):

1. Push this folder to a GitHub repo.
2. Import the repo in Vercel/Netlify.
3. Build command: `npm run build` — output directory: `dist`.
4. Add `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, and `VITE_COACH_PIN`
   as environment variables in the host's dashboard.
5. Deploy. You'll get a URL like `blueprint-pitching.vercel.app` —
   `?client=lindsey` on the end is what you send athletes,
   `?coach=1` is what you use yourself.

Both hosts have free tiers that comfortably cover 6 clients checking boxes
on their phones.
