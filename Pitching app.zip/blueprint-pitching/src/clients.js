/* ============================================================================
   CLIENTS
   ----------------------------------------------------------------------------
   One entry per client. The key (e.g. "lindsey") becomes their URL:
     yoursite.com/?client=lindsey

   To add a new client:
     1. Copy an existing entry below (start to finish, including all 5
        domains).
     2. Change the key, `name`, and `pin` (4 digits, must be unique per
        client — this is what keeps clients from opening each other's link
        and seeing each other's logs. It's a light gate, not real security).
     3. Replace the week content with that client's actual programming.
        Any week you leave out will show a clean "programming in progress"
        placeholder instead of breaking.
     4. Optionally add a `video` field to any drill — a link to a demo clip
        (YouTube, Drive, etc). It shows as a "Watch demo" button under
        that drill, visible whether or not it's been checked off yet.
     5. Send them their link + PIN.

   You can also add a client from inside the app now (Coach Dashboard →
   + Add Client) instead of editing this file — see README "Adding clients
   from inside the app." Clients added that way live in Supabase and are
   layered on top of whatever's here at runtime.

   Domain keys are fixed and shared across all clients: prep, throwing,
   lifting, conditioning, armcare. Labels, icons, and colors for those live
   in App.jsx (DOMAIN_META) so branding stays consistent across every
   client — only the training content (and PIN) changes per client here.

   ----------------------------------------------------------------------------
   WEEKS ARE DATES, NOT NUMBERS
   ----------------------------------------------------------------------------
   `weeks` is keyed by the ISO date (YYYY-MM-DD) of that week's Monday —
   e.g. "2026-08-17" for the week of Aug 17. This is an ongoing program, not
   a fixed N-week cycle, so there's no "week 12" to build toward — you're
   just keeping a rolling few weeks of programming ahead of where the
   client actually is.

   You don't need to plan far ahead. In practice, keep about 4 weeks of
   dated entries in place at any time (this week + the next ~3) and add a
   new one every so often as time passes — the app shows whatever dated
   weeks exist and picks the current one automatically when the client
   opens the app. Each domain's header shows "Programmed through {date}"
   so you can see at a glance when a client is about to run out.

   To add the next week for a client: use the in-app week editor (fastest),
   or copy a week block here, change its key to the next Monday's date, and
   write that week's content.
============================================================================ */

export const CLIENTS = {
  lindsey: {
    name: "Lindsey",
    pin: "3197",
    programs: {
      prep: {
        blurb:
          "Restore position before you ask for output. Breathing and mobility set the ribcage, pelvis, and hips so the throwing motion has somewhere to go.",
        weeks: {
          "2026-08-10": {
            focus: "Baseline mobility and breathing pattern",
            blocks: [
              {
                title: "Dynamic Warm-Up",
                items: [
                  { name: "Leg swings (front-to-back)", detail: "2 x 10/side", cue: "Tall posture, swing from the hip." },
                  { name: "Walking lunge w/ rotation", detail: "2 x 8/side", cue: "Rotate toward the front leg at the bottom of each lunge." },
                  { name: "High knees", detail: "2 x 20 yd", cue: "Drive the knee up, land underneath your hips." },
                  { name: "Arm circles (small to large)", detail: "1 x 10 each direction", cue: "Build the range gradually." },
                ],
              },
              {
                title: "Breathing Reset",
                items: [
                  { name: "90/90 hip lift w/ balloon", detail: "3 x 10 breaths", cue: "Exhale fully, flatten the low back into the floor. No arching." },
                  { name: "Wall dead bug", detail: "3 x 6/side", cue: "Press low back flat against wall through the whole rep." },
                ],
              },
            ],
          },
          "2026-08-17": {
            focus: "Add rotation control on top of the breathing base",
            blocks: [
              {
                title: "Dynamic Warm-Up",
                items: [
                  { name: "Leg swings (front-to-back)", detail: "2 x 10/side", cue: "Same as last week." },
                  { name: "High knees", detail: "2 x 20 yd", cue: "Drive the knee up, land underneath your hips." },
                  { name: "Inchworm to push-up", detail: "2 x 6", cue: "Walk hands out slow, one clean push-up, walk feet back in." },
                ],
              },
              {
                title: "Rotation Control",
                items: [
                  { name: "Split-stance chop", detail: "3 x 8/side", cue: "Rotate through the trunk, not the front knee." },
                  { name: "Half-kneeling adductor rock", detail: "2 x 8/side", cue: "Stay tall through the torso as you rock back." },
                ],
              },
            ],
          },
          "2026-08-24": {
            focus: "Hold the pattern, extend hold times",
            blocks: [
              {
                title: "Dynamic Warm-Up",
                items: [
                  { name: "Leg swings (lateral)", detail: "2 x 10/side", cue: "Light hand support only, control the swing." },
                  { name: "Carioca", detail: "2 x 20 yd/side", cue: "Stay low and loose through the hips." },
                  { name: "Inchworm to push-up", detail: "2 x 6", cue: "Same as last week." },
                ],
              },
              {
                title: "Breathing Reset",
                items: [
                  { name: "90/90 hip lift w/ balloon", detail: "3 x 10 breaths, 3-count hold", cue: "Add a hold at full exhale this week." },
                ],
              },
            ],
          },
          "2026-08-31": {
            focus: "Combine breathing + rotation into one flow",
            blocks: [
              {
                title: "Dynamic Warm-Up",
                items: [
                  { name: "Walking lunge w/ rotation", detail: "2 x 8/side", cue: "Slightly deeper rotation if it feels clean." },
                  { name: "High knees", detail: "2 x 20 yd", cue: "Drive the knee up, land underneath your hips." },
                ],
              },
              {
                title: "Rotation Control",
                items: [
                  { name: "Split-stance chop", detail: "3 x 10/side", cue: "One set heavier than week 2." },
                  { name: "Standing wall reach", detail: "3 x 8", cue: "Reach overhead without extending the low back." },
                ],
              },
            ],
          },
        },
      },

      throwing: {
        blurb:
          "Volume and intent are managed on purpose, not by feel. Every throw builds toward mound intensity — none of it is wasted movement.",
        weeks: {
          "2026-08-10": {
            focus: "Plyo intro + light catch play, reestablish arm speed",
            blocks: [
              {
                title: "Plyo Ball Series",
                items: [
                  { name: "Rockers", detail: "2 x 8/side", cue: "Load into the back hip before the ball leaves the hand." },
                  { name: "Reverse throws", detail: "2 x 8", cue: "Feel the deceleration through the back side, not the elbow." },
                ],
              },
              {
                title: "Catch Play",
                items: [{ name: "Flat ground build-up", detail: "36 – 90 ft, 25 throws", cue: "Stay on line. Distance is earned, not forced." }],
              },
            ],
          },
          "2026-08-17": {
            focus: "Extend distance",
            blocks: [
              {
                title: "Plyo Ball Series",
                items: [
                  { name: "Rockers", detail: "2 x 8/side", cue: "Same as last week, increase intent slightly." },
                  { name: "Roll-ins", detail: "2 x 6", cue: "Front side stays closed until foot strike." },
                ],
              },
              {
                title: "Catch Play",
                items: [{ name: "Flat ground build-up", detail: "36 – 120 ft, 25 throws", cue: "Hold shape at max distance — don't sell out for range." }],
              },
            ],
          },
          "2026-08-24": {
            focus: "Introduce pull-downs",
            blocks: [
              {
                title: "Plyo Ball Series",
                items: [
                  { name: "Run-and-guns", detail: "2 x 6", cue: "Let the crow-hop set the tempo, don't rush it." },
                ],
              },
              {
                title: "Catch Play",
                items: [
                  { name: "Flat ground build-up", detail: "36 – 120 ft, 25 throws", cue: "Same as last week." },
                  { name: "Pull-downs", detail: "90 ft, 6 throws", cue: "Full intent on the last 2 only." },
                ],
              },
            ],
          },
          "2026-08-31": {
            focus: "Build pull-down volume",
            blocks: [
              {
                title: "Plyo Ball Series",
                items: [
                  { name: "Rockers", detail: "2 x 8/side", cue: "Same pattern, continue building intent." },
                  { name: "Run-and-guns", detail: "2 x 8", cue: "Two more reps than last week." },
                ],
              },
              {
                title: "Catch Play",
                items: [
                  { name: "Flat ground build-up", detail: "36 – 120 ft, 25 throws", cue: "Same as last week." },
                  { name: "Pull-downs", detail: "90 ft, 8 throws", cue: "Full intent on the last 3." },
                ],
              },
            ],
          },
        },
      },

      lifting: {
        blurb:
          "Force production off the back leg and rotational power through the trunk. The weight room supports the mound — it doesn't compete with it.",
        weeks: {
          "2026-08-10": {
            focus: "Establish loading patterns, moderate intensity",
            blocks: [
              {
                title: "Primary Lifts",
                items: [
                  { name: "Trap bar deadlift", detail: "4 x 5 @ RPE 7", cue: "Push the floor away — don't yank the bar up." },
                  { name: "Single-leg RDL", detail: "3 x 8/side", cue: "Hips stay square to the floor through the whole rep." },
                ],
              },
              {
                title: "Power & Core",
                items: [
                  { name: "Rotational med ball throw", detail: "3 x 5/side", cue: "Separate hips from shoulders before release." },
                  { name: "Pallof press", detail: "3 x 10/side", cue: "Resist the rotation — don't let the band win." },
                ],
              },
            ],
          },
          "2026-08-17": {
            focus: "Add landmine work, hold deadlift intensity",
            blocks: [
              {
                title: "Primary Lifts",
                items: [
                  { name: "Trap bar deadlift", detail: "4 x 5 @ RPE 7", cue: "Same weight as last week — build the pattern first." },
                  { name: "Landmine press", detail: "3 x 8/side", cue: "Brace before you press, not during." },
                ],
              },
              {
                title: "Power & Core",
                items: [{ name: "Rotational med ball throw", detail: "3 x 6/side", cue: "One more rep than last week, same intent." }],
              },
            ],
          },
          "2026-08-24": {
            focus: "Progress deadlift load",
            blocks: [
              {
                title: "Primary Lifts",
                items: [
                  { name: "Trap bar deadlift", detail: "4 x 5 @ RPE 8", cue: "Small jump in weight from the last two weeks." },
                  { name: "Single-leg RDL", detail: "3 x 8/side", cue: "Same as week 1, keep the pattern clean under slightly more fatigue." },
                ],
              },
              {
                title: "Power & Core",
                items: [{ name: "Pallof press", detail: "3 x 12/side", cue: "Two more reps per side than week 1." }],
              },
            ],
          },
          "2026-08-31": {
            focus: "Consolidate the block",
            blocks: [
              {
                title: "Primary Lifts",
                items: [
                  { name: "Trap bar deadlift", detail: "4 x 5 @ RPE 8", cue: "Hold last week's weight, focus on bar speed." },
                  { name: "Landmine press", detail: "3 x 10/side", cue: "Two more reps than week 2." },
                ],
              },
              {
                title: "Power & Core",
                items: [{ name: "Rotational med ball throw", detail: "3 x 6/side @ max intent", cue: "Same volume as week 2, higher intent." }],
              },
            ],
          },
        },
      },

      conditioning: {
        blurb:
          "Pitching is a repeated-sprint event, not an endurance event. This work builds recovery speed between max-effort bursts — no long distance running in this program.",
        weeks: {
          "2026-08-10": {
            focus: "Build-up sprints, establish top-end mechanics",
            blocks: [
              {
                title: "Sprint Work",
                items: [{ name: "Build-up sprints", detail: "6 x 20 yd @ 60–90%", cue: "Build into top speed — don't be at max effort from step one." }],
              },
              {
                title: "Conditioning",
                items: [{ name: "Bike sprints", detail: "6 rounds — 20s on / 40s off", cue: "Full recovery between rounds — this is about output, not fatigue." }],
              },
            ],
          },
          "2026-08-17": {
            focus: "Introduce direction changes",
            blocks: [
              {
                title: "Sprint Work",
                items: [
                  { name: "Build-up sprints", detail: "6 x 20 yd @ 90%", cue: "Push closer to top effort than last week." },
                  { name: "Shuffle-to-sprint", detail: "4 x 15 yd", cue: "Stay low in the shuffle, explode out of the transition." },
                ],
              },
              {
                title: "Conditioning",
                items: [{ name: "Bike sprints", detail: "6 rounds — 20s on / 40s off", cue: "Same as last week." }],
              },
            ],
          },
          "2026-08-24": {
            focus: "Add light resistance",
            blocks: [
              {
                title: "Sprint Work",
                items: [{ name: "Sled push, light load", detail: "4 x 15 yd", cue: "Stay tall, drive through the ground — don't lean into the sled." }],
              },
              {
                title: "Conditioning",
                items: [{ name: "Bike sprints", detail: "7 rounds — 20s on / 40s off", cue: "One more round than last week." }],
              },
            ],
          },
          "2026-08-31": {
            focus: "Build conditioning volume",
            blocks: [
              {
                title: "Sprint Work",
                items: [
                  { name: "Build-up sprints", detail: "6 x 20 yd @ 90–95%", cue: "Same as week 2, push a bit closer to top effort." },
                  { name: "Sled push, light load", detail: "4 x 15 yd", cue: "Same as last week." },
                ],
              },
              {
                title: "Conditioning",
                items: [{ name: "Bike sprints", detail: "8 rounds — 20s on / 40s off", cue: "One more round than last week." }],
              },
            ],
          },
        },
      },

      armcare: {
        blurb:
          "This section never tapers. Volume on everything else fluctuates by week — arm care doesn't. It runs every single day of the program, in-season and out.",
        weeks: {
          "2026-08-10": {
            blocks: [
              {
                title: "Band Series (daily)",
                items: [
                  { name: "External rotation @ 90°", detail: "2 x 15", cue: "Elbow pinned at the side, don't let it drift forward." },
                  { name: "Internal rotation @ 90°", detail: "2 x 15", cue: "Control the eccentric — don't just release it." },
                ],
              },
              {
                title: "Scap Stability (daily)",
                items: [{ name: "Prone scap retraction", detail: "2 x 12", cue: "Squeeze the shoulder blades down and back, not up." }],
              },
            ],
          },
          "2026-08-17": {
            blocks: [
              {
                title: "Band Series (daily)",
                items: [
                  { name: "External rotation @ 90°", detail: "2 x 15", cue: "Same as last week — this pattern doesn't change." },
                  { name: "Y-T-W raises", detail: "2 x 10 each position", cue: "Thumbs up on the Y and T, lead with the elbows on the W." },
                ],
              },
              {
                title: "Scap Stability (daily)",
                items: [{ name: "Wall slides", detail: "2 x 10", cue: "Keep the low back flat against the wall the entire rep." }],
              },
            ],
          },
          "2026-08-24": {
            blocks: [
              {
                title: "Band Series (daily)",
                items: [
                  { name: "External rotation @ 90°", detail: "2 x 15", cue: "Same as last week." },
                  { name: "Internal rotation @ 90°", detail: "2 x 15", cue: "Same as last week." },
                ],
              },
              {
                title: "Scap Stability (daily)",
                items: [
                  { name: "Prone scap retraction", detail: "2 x 12", cue: "Same as week 1." },
                  { name: "Side-lying sleeper stretch", detail: "2 x 20 sec/side, gentle", cue: "Stretch to tension, never to pain. Back off if it pinches." },
                ],
              },
            ],
          },
          "2026-08-31": {
            blocks: [
              {
                title: "Band Series (daily)",
                items: [{ name: "J-bands full series", detail: "1 full circuit", cue: "Move to the full circuit now that the base pattern feels clean." }],
              },
              {
                title: "Scap Stability (daily)",
                items: [
                  { name: "Wall slides", detail: "2 x 10", cue: "Same as week 2." },
                  { name: "Side-lying sleeper stretch", detail: "2 x 20 sec/side, gentle", cue: "Same as last week." },
                ],
              },
            ],
          },
        },
      },
    },
  },

  // ---------------------------------------------------------------------
  // Minimal second example: only the current week filled in for two
  // domains, the rest left empty on purpose — this is what a client looks
  // like the day you send their link before you've written more than one
  // week ahead.
  // ---------------------------------------------------------------------
  "sample-client": {
    name: "Sample Client",
    pin: "0001",
    programs: {
      prep: {
        blurb: "Restore position before you ask for output.",
        weeks: {
          "2026-08-10": {
            focus: "Baseline mobility",
            blocks: [
              {
                title: "Dynamic Warm-Up",
                items: [
                  { name: "Leg swings (front-to-back)", detail: "2 x 10/side", cue: "Tall posture, swing from the hip." },
                  { name: "High knees", detail: "2 x 20 yd", cue: "Drive the knee up, land underneath your hips." },
                  { name: "Arm circles (small to large)", detail: "1 x 10 each direction", cue: "Build the range gradually." },
                ],
              },
              {
                title: "Breathing Reset",
                items: [{ name: "90/90 hip lift w/ balloon", detail: "3 x 10 breaths", cue: "Exhale fully, flatten the low back into the floor." }],
              },
            ],
          },
        },
      },
      throwing: { blurb: "Volume and intent are managed on purpose, not by feel.", weeks: {} },
      lifting: { blurb: "Force production off the back leg and rotational power through the trunk.", weeks: {} },
      conditioning: { blurb: "Pitching is a repeated-sprint event, not an endurance event.", weeks: {} },
      armcare: { blurb: "This section never tapers.", weeks: {} },
    },
  },

  // Add jane-doe, mike-rivera, etc. below following the same shape — or
  // use Coach Dashboard → + Add Client to skip editing this file entirely.
};
