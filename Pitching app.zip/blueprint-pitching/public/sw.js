// Minimal service worker — its main job is just to exist, since Chrome/Android
// requires a registered service worker before showing an "Install app" prompt.
// It caches nothing aggressively on purpose: training content changes often,
// and a stale cache would be a worse experience than a normal network fetch.

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // Pass-through — no caching. Add a cache strategy here later if you want
  // offline support for a client with a spotty gym wifi connection.
});

// ----------------------------------------------------------------------------
// PUSH NOTIFICATIONS — shows a system notification when the send-push Edge
// Function delivers a push (see README "Push Notifications"). Payload shape:
// { title, body, url } — url is where notificationclick should focus/open.
// ----------------------------------------------------------------------------
self.addEventListener("push", (event) => {
  let payload = { title: "New message", body: "", url: "/" };
  try {
    payload = { ...payload, ...event.data.json() };
  } catch (e) {
    // non-JSON payload — fall back to defaults
  }

  event.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body,
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      data: { url: payload.url },
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || "/";

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(targetUrl.split("?")[0]) && "focus" in client) {
          return client.focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(targetUrl);
    })
  );
});
